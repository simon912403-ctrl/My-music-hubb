# Music platform (Next.js 15 · React 19 · TypeScript · Tailwind · Framer Motion)

Home (cinematic intro + sections), Songs, Artists, Albums, artist pages, album pages, search,
favourites, and a player that keeps playing while you move between pages.

## Your content: ONE file

Everything about songs, artists, albums and branding lives in **`src/data/library.ts`**.
Put your files in these folders, then type only the file name in that file:

| What            | Folder                    | Example file name        |
|-----------------|---------------------------|--------------------------|
| Logo            | `public/media/branding/`  | `logo.svg` / `logo.png`  |
| Artist photos   | `public/media/artists/`   | `mara-voss.jpg`          |
| Album covers    | `public/media/albums/`    | `glass-hours.jpg`        |
| Songs (audio)   | `public/media/songs/`     | `night-shift-radio.mp3`  |

File names are case-sensitive. Use lowercase, no spaces (`my-song.mp3`).

Sizes that work well: covers 1000x1000 JPG/WebP under 300 KB; artist photos 1000x1250 under 400 KB;
songs MP3 128 kbps (about 1 MB per minute). GitHub's web upload limit is 25 MB per file.

## Other places to edit

- Homepage hero, about text, tour dates, video, social links, booking email: `src/data/content.ts`
- Homepage hero image / about portrait / video: `public/media/hero.svg`, `portrait.svg`, `video.mp4`
- Browser tab icon: replace `src/app/icon.svg`
- Colours and fonts: `tailwind.config.ts`, `src/app/layout.tsx`

## Adding a song, artist or album from your phone

You don't need Codespaces for this — GitHub's own website handles both text edits and file uploads.

**Upload a cover, photo, or song file:**
1. Open your repo on github.com in Chrome and browse into `public/media/albums` (or `artists`, `songs`, `branding`).
2. Tap **Add file**, then **Upload files**.
3. Pick the file from your phone. Keep the file name lowercase with no spaces (e.g. `midnight-drive.jpg`).
4. Scroll down and tap **Commit changes**.

**Point `library.ts` at the new file:**
1. Go back to the repo root and open `src/data/library.ts`.
2. Tap the pencil (edit) icon in the top right.
3. Copy an existing artist, album, or song entry, paste it as a new one, and change the `id`, `title`/`name`, and the file name field to match what you just uploaded.
4. Scroll down and tap **Commit changes**.

Vercel redeploys automatically within a minute or two of any commit to `main`.

## Notes

- Favourites are saved in the visitor's browser (localStorage). No database, no account.
- The volume slider does nothing on iPhones (iOS controls volume with the hardware buttons). Android and desktop are fine.
- If an id in `library.ts` is mistyped, the build fails with a message saying which one.
- Contact form: add `RESEND_API_KEY`, `CONTACT_TO_EMAIL`, `CONTACT_FROM_EMAIL` in Vercel to receive email (see `.env.example`).
