import type { ReactNode } from "react";
import MaskText from "./MaskText";
import { Reveal } from "./Reveal";

/** Big editorial page title used by the Songs / Artists / Albums pages. */
export default function PageHeader({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children?: ReactNode;
}) {
  return (
    <header className="px-6 pt-36 md:px-12 md:pt-52">
      <MaskText
        as="h1"
        text={title}
        className="font-display text-[clamp(4.5rem,22vw,17rem)] leading-[0.85] tracking-[-0.04em]"
      />
      {description && (
        <Reveal className="mt-8 max-w-[44ch] text-base text-mute md:mt-10 md:text-lg">
          <p>{description}</p>
        </Reveal>
      )}
      {children}
    </header>
  );
}
