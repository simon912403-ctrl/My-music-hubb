import Link from "next/link";
import { albumsByArtist, songsByArtist, type Artist } from "@/lib/catalog";
import SmartImage from "./SmartImage";

export default function ArtistCard({ artist }: { artist: Artist }) {
  const albumCount = albumsByArtist(artist.id).length;
  const songCount = songsByArtist(artist.id).length;

  return (
    <Link href={`/artists/${artist.id}`} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden bg-panel">
        <SmartImage
          src={artist.image}
          alt={`Photo of ${artist.name}`}
          width={800}
          height={1000}
          fallbackLabel={artist.name}
          className="h-full w-full object-cover transition-transform duration-[1400ms] ease-cine group-hover:scale-[1.06]"
        />
        <span aria-hidden className="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent" />
      </div>
      <h2 className="mt-5 font-display text-3xl leading-none tracking-tight md:text-4xl">{artist.name}</h2>
      <p className="mt-2 text-sm text-mute">
        {albumCount} {albumCount === 1 ? "album" : "albums"} · {songCount} {songCount === 1 ? "song" : "songs"}
      </p>
    </Link>
  );
}
