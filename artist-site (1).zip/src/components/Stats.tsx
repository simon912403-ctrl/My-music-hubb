"use client";

import { useEffect, useRef } from "react";
import { animate, useInView, useReducedMotion } from "framer-motion";
import { about } from "@/data/content";
import { EASE } from "@/lib/motion";

function Counter({ to, decimals, suffix }: { to: number; decimals: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -15% 0px" });
  const reduce = useReducedMotion();
  const format = (v: number) => `${v.toFixed(decimals)}${suffix}`;

  useEffect(() => {
    const el = ref.current;
    if (!el || !inView) return;
    if (reduce) {
      el.textContent = format(to);
      return;
    }
    // Write straight to the DOM: no React re-render per frame.
    const controls = animate(0, to, {
      duration: 2.4,
      ease: EASE,
      onUpdate: (v) => {
        el.textContent = format(v);
      },
    });
    return () => controls.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inView, reduce, to, decimals, suffix]);

  return (
    <span ref={ref} className="tabular-nums">
      {format(0)}
    </span>
  );
}

export default function Stats() {
  return (
    <dl className="mt-32 grid grid-cols-2 gap-x-6 gap-y-14 border-t border-line pt-14 md:mt-48 md:grid-cols-4 md:gap-x-10">
      {about.stats.map((s) => (
        <div key={s.label} className="flex flex-col-reverse">
          <dt className="mt-3 text-sm text-mute">{s.label}</dt>
          <dd className="font-display text-[clamp(3.5rem,9vw,8rem)] leading-none tracking-[-0.03em]">
            <Counter to={s.value} decimals={s.decimals} suffix={s.suffix} />
          </dd>
        </div>
      ))}
    </dl>
  );
}
