"use client";

import { motion } from "framer-motion";
import { tour } from "@/data/content";
import { parseTourDate } from "@/lib/format";
import { EASE } from "@/lib/motion";
import MaskText from "./MaskText";
import { Reveal } from "./Reveal";

function TicketButton({ soldOut, href, city }: { soldOut?: boolean; href: string; city: string }) {
  if (soldOut) {
    return (
      <span className="inline-flex items-center rounded-full border border-line px-6 py-3 text-sm text-mute">
        Sold out
      </span>
    );
  }
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Get tickets for ${city}`}
      className="relative inline-flex items-center gap-2 overflow-hidden rounded-full border border-bone/40 px-6 py-3 text-sm transition-colors duration-500 group-hover:border-bone"
    >
      <span
        aria-hidden
        className="absolute inset-0 origin-left scale-x-0 bg-bone transition-transform duration-500 ease-cine group-hover:scale-x-100"
      />
      <span className="relative transition-colors duration-500 group-hover:text-ink">Tickets</span>
    </a>
  );
}

export default function TourSection() {
  return (
    <section id="tour" className="relative px-6 py-32 md:px-12 md:py-56">
      <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
        <MaskText
          as="h2"
          text="Tour"
          className="font-display text-[30vw] leading-[0.85] tracking-[-0.04em] md:text-[20vw]"
        />
        <Reveal className="max-w-[32ch] text-base text-mute md:pb-[2vw]">
          Autumn dates across Europe and North America. Buy from the links here to avoid resale prices.
        </Reveal>
      </div>

      <ul className="mt-16 md:mt-28">
        {tour.map((show) => {
          const d = parseTourDate(show.date);
          return (
            <motion.li
              key={show.id}
              className="group relative"
              initial="hidden"
              whileInView="show"
              viewport={{ once: true, margin: "0px 0px -8% 0px" }}
            >
              {/* Divider draws itself in */}
              <motion.span
                aria-hidden
                className="absolute inset-x-0 top-0 h-px origin-left bg-line"
                variants={{ hidden: { scaleX: 0 }, show: { scaleX: 1, transition: { duration: 1.4, ease: EASE } } }}
              />
              {/* Hover wash */}
              <span
                aria-hidden
                className="absolute inset-0 origin-left scale-x-0 bg-panel transition-transform duration-700 ease-cine group-hover:scale-x-100"
              />

              <motion.div
                className="relative grid grid-cols-[auto_1fr] items-center gap-x-6 gap-y-3 py-8 md:grid-cols-[9rem_1.4fr_1fr_10rem_auto] md:gap-x-8 md:px-6 md:py-10"
                variants={{
                  hidden: { opacity: 0, y: 24 },
                  show: { opacity: 1, y: 0, transition: { duration: 1, ease: EASE, delay: 0.15 } },
                }}
              >
                <div className="col-span-2 flex items-baseline gap-3 text-sm text-mute md:col-span-1 md:block">
                  <p className="font-display text-4xl leading-none text-bone md:text-5xl">
                    {d.day} {d.month}
                  </p>
                  <p className="md:mt-2">
                    {d.weekday} {d.year}
                  </p>
                </div>

                <h3 className="col-span-2 font-display text-[clamp(2.5rem,5.5vw,5rem)] leading-none tracking-[-0.02em] transition-transform duration-700 ease-cine group-hover:translate-x-3 md:col-span-1">
                  {show.city}
                </h3>

                <p className="text-bone/80">{show.venue}</p>
                <p className="text-mute md:text-left">{show.country}</p>

                <div className="col-span-2 mt-2 md:col-span-1 md:mt-0 md:justify-self-end">
                  <TicketButton soldOut={show.soldOut} href={show.ticketUrl} city={show.city} />
                </div>
              </motion.div>
            </motion.li>
          );
        })}
        <li aria-hidden className="h-px bg-line" />
      </ul>
    </section>
  );
}
