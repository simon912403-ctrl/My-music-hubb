"use client";

import { Fragment, useRef, type ElementType } from "react";
import { motion, useInView } from "framer-motion";
import { EASE } from "@/lib/motion";

type Props = {
  text: string;
  as?: ElementType;
  className?: string;
  /** Reveal per word (default) or per character. */
  by?: "word" | "char";
  /** Seconds before the first piece starts. */
  delay?: number;
  stagger?: number;
  /** Controlled trigger. When omitted, reveals once when scrolled into view. */
  active?: boolean;
};

const piece = {
  hidden: { y: "115%" },
  show: (delay: number) => ({ y: "0%", transition: { duration: 1.1, ease: EASE, delay } }),
};

function Mask({ delay, children }: { delay: number; children: React.ReactNode }) {
  return (
    <span className="-my-[0.08em] inline-block overflow-hidden py-[0.08em] align-bottom">
      <motion.span className="inline-block" variants={piece} custom={delay}>
        {children}
      </motion.span>
    </span>
  );
}

/** Headline reveal: each word/character rises out of a mask. Accessible via aria-label. */
export default function MaskText({
  text,
  as: Tag = "span",
  className,
  by = "word",
  delay = 0,
  stagger,
  active,
}: Props) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -12% 0px" });
  const show = active ?? inView;
  const step = stagger ?? (by === "char" ? 0.05 : 0.09);
  const words = text.split(" ");
  let n = 0;

  return (
    <Tag className={className} aria-label={text}>
      <motion.span
        ref={ref}
        aria-hidden="true"
        initial="hidden"
        animate={show ? "show" : "hidden"}
      >
        {words.map((word, wi) => (
          <Fragment key={wi}>
            <span className="inline-block whitespace-nowrap">
              {by === "char" ? (
                word.split("").map((ch, ci) => (
                  <Mask key={ci} delay={delay + n++ * step}>
                    {ch}
                  </Mask>
                ))
              ) : (
                <Mask delay={delay + n++ * step}>{word}</Mask>
              )}
            </span>
            {wi < words.length - 1 ? " " : null}
          </Fragment>
        ))}
      </motion.span>
    </Tag>
  );
}
