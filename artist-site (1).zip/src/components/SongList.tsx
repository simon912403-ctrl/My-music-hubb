"use client";

import type { Song } from "@/lib/catalog";
import SongRow from "./SongRow";

export default function SongList({
  songs,
  showArtist,
  showAlbum,
}: {
  songs: Song[];
  showArtist?: boolean;
  showAlbum?: boolean;
}) {
  return (
    <ul className="border-b border-line">
      {songs.map((s) => (
        <SongRow key={s.id} song={s} queue={songs} showArtist={showArtist} showAlbum={showAlbum} />
      ))}
    </ul>
  );
}
