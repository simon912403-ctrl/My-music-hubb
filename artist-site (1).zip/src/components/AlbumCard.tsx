import Link from "next/link";
import type { Album } from "@/lib/catalog";
import SmartImage from "./SmartImage";

export default function AlbumCard({ album, showArtist = true }: { album: Album; showArtist?: boolean }) {
  return (
    <Link href={`/albums/${album.id}`} className="group block">
      <div className="relative aspect-square overflow-hidden bg-panel">
        <SmartImage
          src={album.cover}
          alt={`Cover of ${album.title}`}
          width={800}
          height={800}
          fallbackLabel={album.title}
          className="h-full w-full object-cover transition-transform duration-[1400ms] ease-cine group-hover:scale-[1.06]"
        />
      </div>
      <h2 className="mt-5 font-display text-3xl leading-none tracking-tight md:text-4xl">{album.title}</h2>
      <p className="mt-2 text-sm text-mute">
        {showArtist ? `${album.artist} · ` : ""}
        <span className="tabular-nums">{album.year}</span>
      </p>
    </Link>
  );
}
