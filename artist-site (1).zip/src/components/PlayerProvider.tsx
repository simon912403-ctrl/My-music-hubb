"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useMotionValue, type MotionValue } from "framer-motion";
import type { Song } from "@/lib/catalog";

type PlayerContextValue = {
  current: Song | null;
  queue: Song[];
  playing: boolean;
  loading: boolean;
  error: string | null;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  hasNext: boolean;
  hasPrev: boolean;
  /** 0..1, updated every frame without re-rendering React. Bind to a `scaleX` style. */
  progress: MotionValue<number>;
  /** Play a song (optionally within a list, so next/previous work), or pause/resume it if already current. */
  toggle: (song: Song, queue?: Song[]) => void;
  /** Start a list from its first song. */
  playList: (queue: Song[]) => void;
  pause: () => void;
  resume: () => void;
  next: () => void;
  prev: () => void;
  seek: (seconds: number) => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  close: () => void;
};

const PlayerContext = createContext<PlayerContextValue | null>(null);
const VOLUME_KEY = "lowlight:volume";

export function usePlayer() {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error("usePlayer must be used inside <PlayerProvider>");
  return ctx;
}

/** One shared <audio> element, so only one song ever plays at a time, across every page. */
export function PlayerProvider({ children }: { children: ReactNode }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentRef = useRef<Song | null>(null);
  const queueRef = useRef<Song[]>([]);
  const nextRef = useRef<() => boolean>(() => false);
  const prevRef = useRef<() => void>(() => {});
  const progress = useMotionValue(0);

  const [current, setCurrent] = useState<Song | null>(null);
  const [queue, setQueue] = useState<Song[]>([]);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(1);
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    const audio = new Audio();
    audio.preload = "none";
    audioRef.current = audio;
    let raf = 0;

    try {
      const stored = window.localStorage.getItem(VOLUME_KEY);
      if (stored !== null) {
        const v = Math.max(0, Math.min(1, Number(stored)));
        if (Number.isFinite(v)) {
          audio.volume = v;
          setVolumeState(v);
        }
      }
    } catch {
      /* ignore */
    }

    const tick = () => {
      if (audio.duration) progress.set(audio.currentTime / audio.duration);
      raf = requestAnimationFrame(tick);
    };
    const stopTick = () => {
      cancelAnimationFrame(raf);
      raf = 0;
    };

    const onPlay = () => {
      setPlaying(true);
      setError(null);
      stopTick();
      raf = requestAnimationFrame(tick);
    };
    const onPause = () => {
      setPlaying(false);
      stopTick();
    };
    const onTime = () => setCurrentTime(audio.currentTime);
    const onMeta = () => setDuration(Number.isFinite(audio.duration) ? audio.duration : 0);
    const onEnded = () => {
      // Move on to the next song in the list; stop at the end.
      if (nextRef.current()) return;
      setPlaying(false);
      stopTick();
      progress.set(0);
      setCurrentTime(0);
    };
    const onWaiting = () => setLoading(true);
    const onCanPlay = () => setLoading(false);
    const onError = () => {
      stopTick();
      setPlaying(false);
      setLoading(false);
      if (audio.getAttribute("src")) setError("Audio file not found");
    };

    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onMeta);
    audio.addEventListener("durationchange", onMeta);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("waiting", onWaiting);
    audio.addEventListener("canplay", onCanPlay);
    audio.addEventListener("error", onError);

    // Lock-screen / headset / notification controls (Android, iOS, desktop)
    if ("mediaSession" in navigator) {
      const ms = navigator.mediaSession;
      ms.setActionHandler("play", () => void audio.play().catch(() => {}));
      ms.setActionHandler("pause", () => audio.pause());
      ms.setActionHandler("nexttrack", () => {
        nextRef.current();
      });
      ms.setActionHandler("previoustrack", () => prevRef.current());
    }

    return () => {
      stopTick();
      audio.pause();
      audio.removeAttribute("src");
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onMeta);
      audio.removeEventListener("durationchange", onMeta);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("waiting", onWaiting);
      audio.removeEventListener("canplay", onCanPlay);
      audio.removeEventListener("error", onError);
      audioRef.current = null;
    };
  }, [progress]);

  const play = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.play().catch((err: unknown) => {
      // AbortError = another song was picked mid-load; not a real failure.
      if (err instanceof DOMException && err.name === "AbortError") return;
      setError("Tap play to start");
      setLoading(false);
    });
  }, []);

  const load = useCallback(
    (song: Song) => {
      const audio = audioRef.current;
      if (!audio) return;
      audio.pause();
      audio.src = song.audio;
      progress.set(0);
      setCurrentTime(0);
      setDuration(0);
      setError(null);
      setLoading(true);
      currentRef.current = song;
      setCurrent(song);
      play();

      if ("mediaSession" in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: song.title,
          artist: song.artist,
          album: song.album,
        });
      }
    },
    [play, progress],
  );

  const setQueueBoth = useCallback((list: Song[]) => {
    queueRef.current = list;
    setQueue(list);
  }, []);

  const step = useCallback(
    (dir: 1 | -1) => {
      const cur = currentRef.current;
      if (!cur) return false;
      const list = queueRef.current;
      const i = list.findIndex((s) => s.id === cur.id);
      const target = i === -1 ? undefined : list[i + dir];
      if (!target) return false;
      load(target);
      return true;
    },
    [load],
  );

  const next = useCallback(() => {
    step(1);
  }, [step]);

  const prev = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    // Standard behaviour: if a few seconds in, restart; otherwise go to the previous song.
    if (audio.currentTime > 3 || !step(-1)) {
      audio.currentTime = 0;
      progress.set(0);
      setCurrentTime(0);
    }
  }, [step, progress]);

  useEffect(() => {
    nextRef.current = () => step(1);
    prevRef.current = prev;
  }, [step, prev]);

  const toggle = useCallback(
    (song: Song, list?: Song[]) => {
      const audio = audioRef.current;
      if (!audio) return;

      if (list && list.some((s) => s.id === song.id)) setQueueBoth(list);

      if (currentRef.current?.id === song.id) {
        if (audio.paused) play();
        else audio.pause();
        return;
      }
      if (!(list && list.some((s) => s.id === song.id))) setQueueBoth([song]);
      load(song);
    },
    [load, play, setQueueBoth],
  );

  const playList = useCallback(
    (list: Song[]) => {
      if (list.length === 0) return;
      setQueueBoth(list);
      load(list[0]);
    },
    [load, setQueueBoth],
  );

  const pause = useCallback(() => audioRef.current?.pause(), []);
  const resume = useCallback(() => play(), [play]);

  const seek = useCallback(
    (seconds: number) => {
      const audio = audioRef.current;
      if (!audio || !audio.duration) return;
      audio.currentTime = Math.max(0, Math.min(seconds, audio.duration));
      progress.set(audio.currentTime / audio.duration);
      setCurrentTime(audio.currentTime);
    },
    [progress],
  );

  const setVolume = useCallback((v: number) => {
    const audio = audioRef.current;
    const clamped = Math.max(0, Math.min(1, v));
    if (audio) {
      audio.volume = clamped;
      audio.muted = false;
    }
    setVolumeState(clamped);
    setMuted(false);
    try {
      window.localStorage.setItem(VOLUME_KEY, String(clamped));
    } catch {
      /* ignore */
    }
  }, []);

  const toggleMute = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.muted = !audio.muted;
    setMuted(audio.muted);
  }, []);

  const close = useCallback(() => {
    const audio = audioRef.current;
    if (audio) {
      audio.pause();
      audio.removeAttribute("src");
      audio.load();
    }
    progress.set(0);
    currentRef.current = null;
    setQueueBoth([]);
    setCurrent(null);
    setPlaying(false);
    setLoading(false);
    setError(null);
    setCurrentTime(0);
    setDuration(0);
  }, [progress, setQueueBoth]);

  const { hasNext, hasPrev } = useMemo(() => {
    const i = current ? queue.findIndex((s) => s.id === current.id) : -1;
    return { hasNext: i !== -1 && i < queue.length - 1, hasPrev: i > 0 };
  }, [current, queue]);

  const value = useMemo<PlayerContextValue>(
    () => ({
      current, queue, playing, loading, error, currentTime, duration, volume, muted, hasNext, hasPrev, progress,
      toggle, playList, pause, resume, next, prev, seek, setVolume, toggleMute, close,
    }),
    [
      current, queue, playing, loading, error, currentTime, duration, volume, muted, hasNext, hasPrev, progress,
      toggle, playList, pause, resume, next, prev, seek, setVolume, toggleMute, close,
    ],
  );

  return <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>;
}
