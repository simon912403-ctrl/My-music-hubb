export default function EqualizerBars({ playing, className = "" }: { playing: boolean; className?: string }) {
  return (
    <span
      aria-hidden
      className={`flex h-5 items-end gap-[3px] ${playing ? "" : "eq-paused"} ${className}`}
    >
      {[0, 0.25, 0.5, 0.12].map((d, i) => (
        <span key={i} className="eq-bar block h-full w-[3px] bg-signal" style={{ animationDelay: `${d}s` }} />
      ))}
    </span>
  );
}
