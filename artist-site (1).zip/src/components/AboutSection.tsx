"use client";

import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { about, artist } from "@/data/content";
import { useParallax } from "@/hooks/useParallax";
import MaskText from "./MaskText";
import { ClipReveal, Reveal } from "./Reveal";
import Stats from "./Stats";

function Word({ progress, range, children }: { progress: MotionValue<number>; range: [number, number]; children: string }) {
  const opacity = useTransform(progress, range, [0.16, 1]);
  return (
    <motion.span style={{ opacity }} className="inline-block">
      {children}
    </motion.span>
  );
}

/** Statement whose words light up one by one as you scroll through it. */
function ScrollStatement({ text }: { text: string }) {
  const ref = useRef<HTMLParagraphElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 0.85", "end 0.5"] });
  const words = text.split(" ");

  if (reduce) {
    return (
      <p ref={ref} className="font-display text-[clamp(2rem,5vw,4.25rem)] leading-[1.08] tracking-[-0.02em]">
        {text}
      </p>
    );
  }

  return (
    <p ref={ref} className="font-display text-[clamp(2rem,5vw,4.25rem)] leading-[1.08] tracking-[-0.02em]">
      <span className="sr-only">{text}</span>
      <span aria-hidden>
        {words.map((w, i) => {
          const start = i / words.length;
          const end = Math.min(1, start + 1.5 / words.length);
          return (
            <span key={i}>
              <Word progress={scrollYProgress} range={[start, end]}>
                {w}
              </Word>{" "}
            </span>
          );
        })}
      </span>
    </p>
  );
}

export default function AboutSection() {
  const portraitRef = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const imgY = useParallax(portraitRef, ["-9%", "9%"]);
  const { scrollYProgress } = useScroll({ target: portraitRef, offset: ["start end", "end start"] });
  const imgScale = useTransform(scrollYProgress, [0, 1], reduce ? [1, 1] : [1.25, 1.05]);

  return (
    <section id="about" className="relative px-6 py-32 md:px-12 md:py-56">
      <MaskText
        as="h2"
        text="About"
        className="font-display text-[30vw] leading-[0.85] tracking-[-0.04em] md:text-[20vw]"
      />

      <div className="mt-16 grid gap-16 md:mt-24 md:grid-cols-12 md:gap-x-10">
        {/* Portrait: taller crop on phones, offset column on desktop */}
        <div className="md:col-span-5">
          <ClipReveal className="md:sticky md:top-24">
            <div ref={portraitRef} className="relative aspect-[4/5] overflow-hidden bg-panel md:aspect-[3/4]">
              <motion.div className="absolute -inset-y-[10%] inset-x-0" style={{ y: imgY, scale: imgScale }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={artist.portrait}
                  alt={`Portrait of ${artist.name}`}
                  width={1000}
                  height={1300}
                  loading="lazy"
                  decoding="async"
                  className="h-full w-full object-cover"
                />
              </motion.div>
            </div>
          </ClipReveal>
        </div>

        <div className="md:col-span-7 md:pl-10 md:pt-24">
          <ScrollStatement text={about.statement} />
          <div className="mt-14 max-w-[60ch] space-y-6 text-lg leading-relaxed text-bone/70">
            {about.paragraphs.map((p, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <p>{p}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </div>

      <Stats />
    </section>
  );
}
