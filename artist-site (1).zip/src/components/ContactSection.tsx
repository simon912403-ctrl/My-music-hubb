"use client";

import { useState, type FormEvent } from "react";
import { artist, socials } from "@/data/content";
import MaskText from "./MaskText";
import { Reveal } from "./Reveal";

type FieldName = "name" | "email" | "message";
type Status = "idle" | "sending" | "success" | "error";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(v: Record<FieldName, string>) {
  const e: Partial<Record<FieldName, string>> = {};
  if (v.name.trim().length < 2) e.name = "Enter your name.";
  if (!EMAIL_RE.test(v.email.trim())) e.email = "Enter a valid email address.";
  if (v.message.trim().length < 10) e.message = "Write at least 10 characters.";
  return e;
}

export default function ContactSection() {
  const [values, setValues] = useState({ name: "", email: "", message: "", company: "" });
  const [errors, setErrors] = useState<Partial<Record<FieldName, string>>>({});
  const [status, setStatus] = useState<Status>("idle");
  const [serverError, setServerError] = useState("");

  const set = (k: keyof typeof values) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setValues((prev) => ({ ...prev, [k]: e.target.value }));
    if (k !== "company" && errors[k]) setErrors((prev) => ({ ...prev, [k]: undefined }));
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (status === "sending") return;

    const errs = validate(values);
    setErrors(errs);
    const first = (["name", "email", "message"] as FieldName[]).find((k) => errs[k]);
    if (first) {
      document.getElementById(`field-${first}`)?.focus();
      return;
    }

    setStatus("sending");
    setServerError("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Something went wrong.");
      }
      setStatus("success");
      setValues({ name: "", email: "", message: "", company: "" });
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Something went wrong.");
      setStatus("error");
    }
  };

  return (
    <section id="contact" className="relative px-6 py-32 md:px-12 md:py-56">
      <MaskText
        as="h2"
        text="Contact"
        className="font-display text-[30vw] leading-[0.85] tracking-[-0.04em] md:text-[20vw]"
      />

      <div className="mt-16 grid gap-20 md:mt-28 md:grid-cols-12 md:gap-x-10">
        <div className="md:col-span-5">
          <Reveal>
            <p className="text-base text-mute">Booking, press and licensing</p>
            <a
              href={`mailto:${artist.email}`}
              className="mt-4 block break-words font-display text-[clamp(1.9rem,4vw,3.25rem)] leading-tight tracking-[-0.02em] underline decoration-bone/30 underline-offset-8 transition-colors hover:decoration-signal"
            >
              {artist.email}
            </a>
          </Reveal>
          <Reveal delay={0.1} className="mt-14">
            <ul className="flex flex-wrap gap-x-8 gap-y-3">
              {socials.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-bone/80 underline decoration-transparent underline-offset-4 transition-colors hover:text-bone hover:decoration-signal"
                  >
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>

        <Reveal className="md:col-span-7 md:pl-10" delay={0.1}>
          {status === "success" ? (
            <div role="status" className="py-8">
              <p className="font-display text-5xl leading-tight tracking-tight">Message sent.</p>
              <p className="mt-4 max-w-[40ch] text-mute">Thanks for getting in touch. You will get a reply by email.</p>
              <button
                type="button"
                onClick={() => setStatus("idle")}
                className="mt-8 rounded-full border border-bone/30 px-6 py-3 text-sm transition-colors hover:bg-bone hover:text-ink"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-10">
              <div>
                <label htmlFor="field-name" className="text-sm text-mute">
                  Name
                </label>
                <input
                  id="field-name"
                  name="name"
                  type="text"
                  autoComplete="name"
                  value={values.name}
                  onChange={set("name")}
                  aria-invalid={errors.name ? "true" : "false"}
                  aria-describedby={errors.name ? "err-name" : undefined}
                  className="field"
                />
                {errors.name && (
                  <p id="err-name" className="mt-2 text-sm text-[#ff8a8a]">
                    {errors.name}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="field-email" className="text-sm text-mute">
                  Email
                </label>
                <input
                  id="field-email"
                  name="email"
                  type="email"
                  inputMode="email"
                  autoComplete="email"
                  value={values.email}
                  onChange={set("email")}
                  aria-invalid={errors.email ? "true" : "false"}
                  aria-describedby={errors.email ? "err-email" : undefined}
                  className="field"
                />
                {errors.email && (
                  <p id="err-email" className="mt-2 text-sm text-[#ff8a8a]">
                    {errors.email}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="field-message" className="text-sm text-mute">
                  Message
                </label>
                <textarea
                  id="field-message"
                  name="message"
                  rows={5}
                  value={values.message}
                  onChange={set("message")}
                  aria-invalid={errors.message ? "true" : "false"}
                  aria-describedby={errors.message ? "err-message" : undefined}
                  className="field resize-none"
                />
                {errors.message && (
                  <p id="err-message" className="mt-2 text-sm text-[#ff8a8a]">
                    {errors.message}
                  </p>
                )}
              </div>

              {/* Honeypot: hidden from people, tempting to bots */}
              <div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                <label htmlFor="field-company">Company</label>
                <input
                  id="field-company"
                  name="company"
                  type="text"
                  tabIndex={-1}
                  autoComplete="off"
                  value={values.company}
                  onChange={set("company")}
                />
              </div>

              <div className="flex flex-wrap items-center gap-6">
                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="group relative overflow-hidden rounded-full border border-bone/40 px-10 py-4 text-sm transition-colors duration-500 hover:border-bone disabled:opacity-60"
                >
                  <span
                    aria-hidden
                    className="absolute inset-0 origin-bottom scale-y-0 bg-bone transition-transform duration-500 ease-cine group-hover:scale-y-100"
                  />
                  <span className="relative transition-colors duration-500 group-hover:text-ink">
                    {status === "sending" ? "Sending" : "Send message"}
                  </span>
                </button>
                <p role="alert" className="text-sm text-[#ff8a8a]">
                  {status === "error" ? serverError : ""}
                </p>
              </div>
            </form>
          )}
        </Reveal>
      </div>
    </section>
  );
}
