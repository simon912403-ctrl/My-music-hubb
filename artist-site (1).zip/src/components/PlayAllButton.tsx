"use client";

import type { Song } from "@/lib/catalog";
import { usePlayer } from "./PlayerProvider";

/** Plays a whole list from the top (or pauses / resumes it if it is already playing). */
export default function PlayAllButton({ songs, label = "Play all" }: { songs: Song[]; label?: string }) {
  const { current, playing, playList, pause, resume } = usePlayer();
  const inList = !!current && songs.some((s) => s.id === current.id);
  const playingHere = inList && playing;

  return (
    <button
      type="button"
      disabled={songs.length === 0}
      onClick={() => {
        if (playingHere) pause();
        else if (inList) resume();
        else playList(songs);
      }}
      className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full border border-bone/40 px-8 py-4 text-sm transition-colors duration-500 hover:border-bone disabled:opacity-40"
    >
      <span
        aria-hidden
        className="absolute inset-0 origin-bottom scale-y-0 bg-bone transition-transform duration-500 ease-cine group-hover:scale-y-100"
      />
      <svg width="14" height="14" viewBox="0 0 18 18" fill="currentColor" className="relative transition-colors duration-500 group-hover:text-ink" aria-hidden>
        {playingHere ? (
          <>
            <rect x="3" y="2" width="4" height="14" />
            <rect x="11" y="2" width="4" height="14" />
          </>
        ) : (
          <path d="M5 2.5v13L15.5 9z" />
        )}
      </svg>
      <span className="relative transition-colors duration-500 group-hover:text-ink">{playingHere ? "Pause" : label}</span>
    </button>
  );
}
