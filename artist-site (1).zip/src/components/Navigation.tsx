"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { logo, site } from "@/lib/catalog";
import { artist } from "@/data/content";
import { lockScroll, scrollToId, scrollToTop } from "@/lib/scroll";
import { EASE } from "@/lib/motion";
import { useShell } from "./ShellContext";
import SmartImage from "./SmartImage";

const MENU_ORIGIN = "at calc(100% - 44px) 44px";

const primary = [
  { href: "/", label: "Home" },
  { href: "/songs", label: "Songs" },
  { href: "/artists", label: "Artists" },
  { href: "/albums", label: "Albums" },
] as const;

/** Sections of the homepage, reachable from any page. */
const sections = [
  { id: "about", label: "About" },
  { id: "videos", label: "Videos" },
  { id: "tour", label: "Tour" },
  { id: "contact", label: "Contact" },
] as const;

const HOME_SECTION_IDS = ["top", "music", "about", "videos", "tour", "contact"];

export default function Navigation() {
  const pathname = usePathname();
  const { entered, setSearchOpen } = useShell();
  const onHome = pathname === "/";
  const visible = !onHome || entered;

  const [open, setOpen] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    const prev = scrollY.getPrevious() ?? 0;
    if (latest < 120) setHidden(false);
    else if (latest > prev + 4) setHidden(true);
    else if (latest < prev - 4) setHidden(false);
  });

  // Which homepage section is in the middle of the viewport (homepage only)
  useEffect(() => {
    setActiveSection(null);
    if (!onHome) return;
    const els = HOME_SECTION_IDS.map((id) => document.getElementById(id)).filter(
      (el): el is HTMLElement => el !== null,
    );
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActiveSection(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [onHome]);

  // Close the mobile menu whenever the page changes
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!visible) return;
    lockScroll(open);
    return () => lockScroll(false);
  }, [open, visible]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const isCurrent = (href: string) => {
    if (href === "/") return onHome && (activeSection === null || ["top", "music", "about", "videos"].includes(activeSection));
    return pathname === href || pathname.startsWith(`${href}/`);
  };

  const goSection = (id: string) => (e: React.MouseEvent) => {
    if (!onHome) return; // let <Link href="/#id"> navigate; ScrollManager scrolls after arrival
    e.preventDefault();
    setOpen(false);
    lockScroll(false);
    window.setTimeout(() => scrollToId(id), 60);
  };

  const showBar = visible && (!hidden || open);

  const linkClass =
    "group relative py-1 text-bone/70 transition-colors duration-300 hover:text-bone aria-[current=true]:text-bone";
  const underline = (
    <span
      aria-hidden
      className="absolute inset-x-0 -bottom-0.5 h-px origin-left scale-x-0 bg-signal transition-transform duration-500 ease-cine group-hover:scale-x-100 group-aria-[current=true]:scale-x-100"
    />
  );

  return (
    <>
      <motion.header
        className="fixed inset-x-0 top-0 z-[60]"
        initial={false}
        animate={showBar ? { y: "0%", opacity: 1 } : { y: "-100%", opacity: 0 }}
        transition={{ duration: 0.7, ease: EASE }}
        style={{ pointerEvents: visible ? "auto" : "none" }}
      >
        <nav
          aria-label="Primary"
          className="flex items-center justify-between gap-6 bg-gradient-to-b from-ink/80 to-transparent px-6 py-4 md:px-12 md:py-6"
        >
          <Link
            href="/"
            onClick={(e) => {
              setOpen(false);
              if (onHome) {
                e.preventDefault();
                scrollToTop();
              }
            }}
            className="flex min-w-0 items-center gap-3"
            aria-label={`${site.name} home`}
          >
            {logo && (
              <SmartImage
                src={logo}
                alt=""
                width={32}
                height={32}
                eager
                className="h-8 w-8 shrink-0 object-contain text-base"
                fallbackLabel={site.name}
              />
            )}
            <span className="truncate font-display text-2xl tracking-tight">{site.name}</span>
          </Link>

          <ul className="hidden items-center gap-8 text-sm md:flex lg:gap-10">
            {primary.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  onClick={(e) => {
                    if (item.href === "/" && onHome) {
                      e.preventDefault();
                      scrollToTop();
                    }
                  }}
                  aria-current={isCurrent(item.href) ? "true" : undefined}
                  className={linkClass}
                >
                  {item.label}
                  {underline}
                </Link>
              </li>
            ))}
            {sections
              .filter((s) => s.id === "tour" || s.id === "contact")
              .map((s) => (
                <li key={s.id} className="hidden lg:block">
                  <Link
                    href={`/#${s.id}`}
                    onClick={goSection(s.id)}
                    aria-current={onHome && activeSection === s.id ? "true" : undefined}
                    className={linkClass}
                  >
                    {s.label}
                    {underline}
                  </Link>
                </li>
              ))}
          </ul>

          <div className="flex items-center">
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              aria-label="Search songs, artists and albums"
              className="grid h-11 w-11 place-items-center text-bone/80 transition-colors hover:text-bone"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden>
                <circle cx="11" cy="11" r="6.5" />
                <path d="M16 16l4.5 4.5" />
              </svg>
            </button>
            <button
              type="button"
              className="relative z-[70] h-11 w-11 md:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen((v) => !v)}
            >
              <span
                aria-hidden
                className="absolute left-1/2 top-1/2 block h-px w-7 bg-bone transition-transform duration-500 ease-cine"
                style={{
                  transform: open ? "translate(-50%, -50%) rotate(45deg)" : "translate(-50%, calc(-50% - 4px))",
                }}
              />
              <span
                aria-hidden
                className="absolute left-1/2 top-1/2 block h-px w-7 bg-bone transition-transform duration-500 ease-cine"
                style={{
                  transform: open ? "translate(-50%, -50%) rotate(-45deg)" : "translate(-50%, calc(-50% + 4px))",
                }}
              />
            </button>
          </div>
        </nav>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            data-lenis-prevent
            className="fixed inset-0 z-[55] flex flex-col justify-end overflow-y-auto bg-ink px-6 pb-12 pt-28 md:hidden"
            initial={{ clipPath: `circle(0vmax ${MENU_ORIGIN})` }}
            animate={{ clipPath: `circle(150vmax ${MENU_ORIGIN})` }}
            exit={{ clipPath: `circle(0vmax ${MENU_ORIGIN})` }}
            transition={{ duration: 0.9, ease: EASE }}
          >
            <ul className="space-y-1">
              {primary.map((item, i) => (
                <li key={item.href} className="overflow-hidden">
                  <motion.div
                    initial={{ y: "100%" }}
                    animate={{ y: "0%" }}
                    transition={{ duration: 0.9, ease: EASE, delay: 0.2 + i * 0.07 }}
                  >
                    <Link
                      href={item.href}
                      onClick={(e) => {
                        setOpen(false);
                        if (item.href === "/" && onHome) {
                          e.preventDefault();
                          lockScroll(false);
                          window.setTimeout(scrollToTop, 60);
                        }
                      }}
                      aria-current={isCurrent(item.href) ? "true" : undefined}
                      className="block font-display text-[clamp(3.25rem,15vw,5.5rem)] leading-[1.05] tracking-[-0.02em] aria-[current=true]:text-signal"
                    >
                      {item.label}
                    </Link>
                  </motion.div>
                </li>
              ))}
            </ul>

            <motion.ul
              className="mt-8 flex flex-wrap gap-x-7 gap-y-3 text-base text-bone/80"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.8 }}
            >
              {sections.map((s) => (
                <li key={s.id}>
                  <Link href={`/#${s.id}`} onClick={goSection(s.id)}>
                    {s.label}
                  </Link>
                </li>
              ))}
            </motion.ul>
            <motion.a
              href={`mailto:${artist.email}`}
              className="mt-8 text-sm text-mute"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.8 }}
            >
              {artist.email}
            </motion.a>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
