"use client";

import { useEffect } from "react";
import { lockScroll } from "@/lib/scroll";
import { useShell } from "./ShellContext";
import IntroScreen from "./IntroScreen";
import Hero from "./Hero";
import MusicSection from "./MusicSection";
import AboutSection from "./AboutSection";
import VideoSection from "./VideoSection";
import TourSection from "./TourSection";
import ContactSection from "./ContactSection";

/** The cinematic homepage: intro screen, hero, and the scrolling sections. */
export default function Experience() {
  const { entered, setEntered } = useShell();

  // Hold the page still behind the intro screen until the visitor enters.
  useEffect(() => {
    if (!entered) {
      window.scrollTo(0, 0);
      lockScroll(true);
    }
    return () => lockScroll(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (entered) lockScroll(false);
  }, [entered]);

  return (
    <>
      <IntroScreen entered={entered} onEnter={() => setEntered(true)} />
      <main>
        <Hero entered={entered} />
        <MusicSection />
        <AboutSection />
        <VideoSection />
        <TourSection />
        <ContactSection />
      </main>
    </>
  );
}
