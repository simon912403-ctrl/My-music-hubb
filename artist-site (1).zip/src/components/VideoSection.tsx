"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { video } from "@/data/content";
import { useParallax } from "@/hooks/useParallax";
import { EASE } from "@/lib/motion";
import { lockScroll } from "@/lib/scroll";
import MaskText from "./MaskText";
import { ClipReveal } from "./Reveal";
import { usePlayer } from "./PlayerProvider";

function VideoModal({ onClose }: { onClose: () => void }) {
  const [failed, setFailed] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      previous?.focus?.();
    };
  }, [onClose]);

  return (
    <motion.div
      role="dialog"
      aria-modal="true"
      aria-label={`${video.title} video`}
      className="fixed inset-0 z-[70] flex items-center justify-center bg-ink/95 p-4 md:p-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5, ease: EASE }}
      onClick={onClose}
    >
      <button
        ref={closeRef}
        type="button"
        onClick={onClose}
        className="absolute right-4 top-4 z-10 rounded-full border border-bone/30 px-5 py-3 text-sm transition-colors hover:bg-bone hover:text-ink md:right-10 md:top-8"
      >
        Close
      </button>
      <motion.div
        className="relative aspect-video w-full max-w-6xl bg-black"
        initial={{ scale: 0.94, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.97, opacity: 0 }}
        transition={{ duration: 0.7, ease: EASE }}
        onClick={(e) => e.stopPropagation()}
      >
        {failed ? (
          <div className="absolute inset-0 grid place-items-center p-8 text-center text-mute">
            <p className="max-w-[36ch]">
              No video file yet. Add your video at <span className="text-bone">public/media/video.mp4</span> and it will
              play here.
            </p>
          </div>
        ) : (
          <video
            className="h-full w-full"
            src={video.src}
            poster={video.poster}
            controls
            autoPlay
            playsInline
            preload="metadata"
            onError={() => setFailed(true)}
          />
        )}
      </motion.div>
    </motion.div>
  );
}

export default function VideoSection() {
  const [open, setOpen] = useState(false);
  const frameRef = useRef<HTMLDivElement>(null);
  const imgY = useParallax(frameRef, ["-10%", "10%"]);
  const { pause } = usePlayer();

  const openVideo = () => {
    pause(); // one thing playing at a time
    setOpen(true);
  };
  const closeVideo = useCallback(() => setOpen(false), []);

  useEffect(() => {
    if (!open) return;
    lockScroll(true);
    return () => lockScroll(false);
  }, [open]);

  return (
    <section id="videos" className="relative py-32 md:py-56">
      <div className="px-6 md:px-12">
        <MaskText
          as="h2"
          text="Videos"
          className="font-display text-[30vw] leading-[0.85] tracking-[-0.04em] md:text-[20vw]"
        />
      </div>

      <ClipReveal className="mt-16 md:mt-24 md:px-12">
        <button
          type="button"
          onClick={openVideo}
          aria-label={`Play ${video.title} video`}
          className="group relative block aspect-[4/5] w-full overflow-hidden bg-panel text-left sm:aspect-video lg:aspect-[21/9]"
        >
          <div ref={frameRef} className="absolute inset-0">
            <motion.div className="absolute -inset-y-[12%] inset-x-0" style={{ y: imgY }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={video.poster}
                alt=""
                width={1600}
                height={900}
                loading="lazy"
                decoding="async"
                className="h-full w-full object-cover transition-transform duration-[1600ms] ease-cine group-hover:scale-[1.05]"
              />
            </motion.div>
          </div>
          <span aria-hidden className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-ink/30" />

          <span
            aria-hidden
            className="absolute left-1/2 top-1/2 grid h-24 w-24 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-bone/50 bg-ink/20 backdrop-blur-sm transition-all duration-700 ease-cine group-hover:h-32 group-hover:w-32 group-hover:border-bone group-hover:bg-bone group-hover:text-ink md:h-28 md:w-28 md:group-hover:h-36 md:group-hover:w-36"
          >
            <svg width="26" height="26" viewBox="0 0 18 18" fill="currentColor">
              <path d="M5 2.5v13L15.5 9z" />
            </svg>
          </span>

          <span className="absolute inset-x-0 bottom-0 flex flex-col gap-4 p-6 md:flex-row md:items-end md:justify-between md:p-10">
            <span>
              <span className="block font-display text-[clamp(2.75rem,7vw,6.5rem)] leading-[0.9] tracking-[-0.03em]">
                {video.title}
              </span>
              <span className="mt-2 block text-sm text-bone/70">{video.subtitle}</span>
            </span>
            <span className="grid grid-cols-1 gap-x-8 gap-y-1 text-sm sm:grid-cols-3 md:block md:text-right">
              {video.info.map((i) => (
                <span key={i.label} className="block">
                  <span className="text-mute">{i.label} </span>
                  <span className="text-bone/90">{i.value}</span>
                </span>
              ))}
            </span>
          </span>
        </button>
      </ClipReveal>

      <AnimatePresence>{open && <VideoModal key="video-modal" onClose={closeVideo} />}</AnimatePresence>
    </section>
  );
}
