"use client";

import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

type ShellValue = {
  /** Homepage intro screen has been dismissed (stays true for the rest of the visit). */
  entered: boolean;
  setEntered: (v: boolean) => void;
  searchOpen: boolean;
  setSearchOpen: (v: boolean) => void;
};

const ShellContext = createContext<ShellValue | null>(null);

export function useShell() {
  const ctx = useContext(ShellContext);
  if (!ctx) throw new Error("useShell must be used inside <ShellProvider>");
  return ctx;
}

export function ShellProvider({ children }: { children: ReactNode }) {
  const [entered, setEntered] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const value = useMemo(() => ({ entered, setEntered, searchOpen, setSearchOpen }), [entered, searchOpen]);
  return <ShellContext.Provider value={value}>{children}</ShellContext.Provider>;
}
