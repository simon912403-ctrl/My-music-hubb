"use client";

import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { artist } from "@/data/content";
import { EASE } from "@/lib/motion";
import { scrollToId } from "@/lib/scroll";
import MaskText from "./MaskText";

export default function Hero({ entered }: { entered: boolean }) {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });

  const imageY = useTransform(scrollYProgress, [0, 1], reduce ? ["0%", "0%"] : ["0%", "18%"]);
  const textY = useTransform(scrollYProgress, [0, 1], reduce ? ["0%", "0%"] : ["0%", "-30%"]);
  const textOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section ref={ref} id="top" className="relative h-[100svh] min-h-[560px] overflow-hidden">
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: entered ? 1 : 0 }}
        transition={{ duration: 2.2, ease: EASE }}
      >
        <motion.div className="absolute -inset-y-[10%] inset-x-0 will-change-transform" style={{ y: imageY }}>
          {/* Eager on purpose: it's the first thing seen after the intro. */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={artist.heroImage}
            alt=""
            width={1800}
            height={1200}
            fetchPriority="high"
            decoding="async"
            className="anim-kenburns h-full w-full object-cover object-[50%_30%]"
          />
        </motion.div>
        <div
          aria-hidden
          className="anim-drift-b pointer-events-none absolute -right-1/4 top-0 h-[70vmax] w-[70vmax] mix-blend-screen will-change-transform"
          style={{ background: "radial-gradient(closest-side, rgba(157,184,255,0.16), transparent)" }}
        />
        <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-ink/55" />
      </motion.div>

      <motion.div
        className="absolute inset-x-0 bottom-0 px-6 pb-28 md:px-12 md:pb-14"
        style={{ y: textY, opacity: textOpacity }}
      >
        <h1 className="font-display text-[34vw] leading-[0.8] tracking-[-0.04em] md:text-[19vw]">
          <MaskText as="span" by="char" text={artist.first} active={entered} delay={0.55} className="block" />
          <MaskText
            as="span"
            by="char"
            text={artist.last}
            active={entered}
            delay={0.85}
            className="block md:pl-[16vw]"
          />
        </h1>
        <motion.p
          className="mt-8 max-w-[24ch] text-base text-bone/80 md:absolute md:bottom-14 md:right-12 md:mt-0 md:max-w-[22ch] md:text-lg"
          initial={{ opacity: 0, y: 16 }}
          animate={entered ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
          transition={{ duration: 1.2, ease: EASE, delay: 1.5 }}
        >
          {artist.tagline}
        </motion.p>
      </motion.div>

      <motion.button
        type="button"
        onClick={() => scrollToId("music")}
        aria-label="Scroll to music"
        className="absolute bottom-5 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2 text-xs text-bone/60"
        initial={{ opacity: 0 }}
        animate={{ opacity: entered ? 1 : 0 }}
        transition={{ delay: 2.2, duration: 1 }}
      >
        Scroll
        <span aria-hidden className="relative block h-12 w-px overflow-hidden bg-bone/20">
          <span className="anim-cue absolute inset-0 bg-bone" />
        </span>
      </motion.button>
    </section>
  );
}
