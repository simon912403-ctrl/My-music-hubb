"use client";

import type { ReactNode } from "react";
import { MotionConfig } from "framer-motion";
import { ShellProvider } from "./ShellContext";
import { LikesProvider } from "./LikesProvider";
import { PlayerProvider } from "./PlayerProvider";
import ScrollManager from "./ScrollManager";
import Navigation from "./Navigation";
import Footer from "./Footer";
import MusicPlayer from "./MusicPlayer";
import SearchDialog from "./SearchDialog";

/** Everything shared by every page: providers, navigation, footer, and the persistent player. */
export default function AppShell({ children }: { children: ReactNode }) {
  return (
    <MotionConfig reducedMotion="user">
      <ShellProvider>
        <LikesProvider>
          <PlayerProvider>
            <ScrollManager />
            <Navigation />
            {children}
            <Footer />
            <MusicPlayer />
            <SearchDialog />
          </PlayerProvider>
        </LikesProvider>
      </ShellProvider>
    </MotionConfig>
  );
}
