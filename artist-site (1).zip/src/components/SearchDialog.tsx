"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { featuredSongs, searchCatalog, type Song } from "@/lib/catalog";
import { EASE } from "@/lib/motion";
import { lockScroll } from "@/lib/scroll";
import { useShell } from "./ShellContext";
import { usePlayer } from "./PlayerProvider";
import SmartImage from "./SmartImage";
import EqualizerBars from "./EqualizerBars";

function ResultHeading({ children }: { children: React.ReactNode }) {
  return <h3 className="mb-2 mt-8 text-sm text-mute first:mt-0">{children}</h3>;
}

function SongResult({ song, list }: { song: Song; list: Song[] }) {
  const { current, playing, toggle } = usePlayer();
  const active = current?.id === song.id;
  return (
    <li>
      <button
        type="button"
        onClick={() => toggle(song, list)}
        aria-label={`${active && playing ? "Pause" : "Play"} ${song.title} by ${song.artist}`}
        className="flex w-full items-center gap-4 border-t border-line py-3 text-left"
      >
        <SmartImage src={song.cover} alt="" width={48} height={48} fallbackLabel={song.album} className="h-12 w-12 shrink-0 object-cover text-lg" />
        <span className="min-w-0 flex-1">
          <span className={`block truncate font-display text-2xl leading-tight ${active ? "text-signal" : ""}`}>{song.title}</span>
          <span className="block truncate text-sm text-mute">
            {song.artist} · {song.album}
          </span>
        </span>
        {active ? <EqualizerBars playing={playing} /> : null}
      </button>
    </li>
  );
}

export default function SearchDialog() {
  const { searchOpen, setSearchOpen } = useShell();
  const pathname = usePathname();
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const results = useMemo(() => searchCatalog(query), [query]);
  const hasQuery = query.trim().length > 0;
  const total = results.songs.length + results.artists.length + results.albums.length;

  // Global shortcut: "/" or Ctrl/Cmd+K opens search
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
      if ((e.key === "k" && (e.metaKey || e.ctrlKey)) || (e.key === "/" && !typing)) {
        e.preventDefault();
        setSearchOpen(true);
      } else if (e.key === "Escape") {
        setSearchOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setSearchOpen]);

  useEffect(() => {
    if (!searchOpen) return;
    lockScroll(true);
    inputRef.current?.focus();
    return () => lockScroll(false);
  }, [searchOpen]);

  // Close after navigating to an artist/album page
  useEffect(() => {
    setSearchOpen(false);
    setQuery("");
  }, [pathname, setSearchOpen]);

  return (
    <AnimatePresence>
      {searchOpen && (
        <motion.div
          key="search"
          role="dialog"
          aria-modal="true"
          aria-label="Search"
          className="fixed inset-0 z-[75] flex flex-col bg-ink/95 backdrop-blur-md"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4, ease: EASE }}
        >
          <div className="flex items-center gap-3 border-b border-line px-6 py-4 md:px-12 md:py-6">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" className="shrink-0 text-mute" aria-hidden>
              <circle cx="11" cy="11" r="6.5" />
              <path d="M16 16l4.5 4.5" />
            </svg>
            <input
              ref={inputRef}
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search songs, artists, albums"
              aria-label="Search songs, artists and albums"
              autoComplete="off"
              autoCapitalize="off"
              spellCheck={false}
              className="min-w-0 flex-1 bg-transparent font-display text-3xl tracking-tight text-bone placeholder:text-mute/70 focus:outline-none md:text-5xl [&::-webkit-search-cancel-button]:hidden"
            />
            <button
              type="button"
              onClick={() => setSearchOpen(false)}
              className="shrink-0 rounded-full border border-bone/30 px-5 py-2.5 text-sm transition-colors hover:bg-bone hover:text-ink"
            >
              Close
            </button>
          </div>

          <div data-lenis-prevent className="flex-1 overflow-y-auto px-6 pb-40 pt-8 md:px-12">
            <div className="mx-auto max-w-3xl" aria-live="polite">
              {!hasQuery && (
                <>
                  <ResultHeading>Featured songs</ResultHeading>
                  <ul>
                    {featuredSongs.map((s) => (
                      <SongResult key={s.id} song={s} list={featuredSongs} />
                    ))}
                  </ul>
                </>
              )}

              {hasQuery && total === 0 && (
                <p className="text-mute">Nothing matches “{query.trim()}”. Try a song title, an artist or an album name.</p>
              )}

              {results.songs.length > 0 && (
                <>
                  <ResultHeading>Songs</ResultHeading>
                  <ul>
                    {results.songs.map((s) => (
                      <SongResult key={s.id} song={s} list={results.songs} />
                    ))}
                  </ul>
                </>
              )}

              {results.artists.length > 0 && (
                <>
                  <ResultHeading>Artists</ResultHeading>
                  <ul>
                    {results.artists.map((a) => (
                      <li key={a.id}>
                        <Link href={`/artists/${a.id}`} className="flex items-center gap-4 border-t border-line py-3">
                          <SmartImage src={a.image} alt="" width={48} height={48} fallbackLabel={a.name} className="h-12 w-12 shrink-0 rounded-full object-cover text-lg" />
                          <span className="truncate font-display text-2xl">{a.name}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </>
              )}

              {results.albums.length > 0 && (
                <>
                  <ResultHeading>Albums</ResultHeading>
                  <ul>
                    {results.albums.map((a) => (
                      <li key={a.id}>
                        <Link href={`/albums/${a.id}`} className="flex items-center gap-4 border-t border-line py-3">
                          <SmartImage src={a.cover} alt="" width={48} height={48} fallbackLabel={a.title} className="h-12 w-12 shrink-0 object-cover text-lg" />
                          <span className="min-w-0">
                            <span className="block truncate font-display text-2xl leading-tight">{a.title}</span>
                            <span className="block truncate text-sm text-mute">
                              {a.artist} · {a.year}
                            </span>
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
