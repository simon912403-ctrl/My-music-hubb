"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { tracks } from "@/data/content";
import { useParallax } from "@/hooks/useParallax";
import MaskText from "./MaskText";
import { Reveal } from "./Reveal";
import TrackCard from "./TrackCard";

/** Phones and reduced-motion: a native swipeable rail. No scroll hijacking. */
function NativeRail({ className = "" }: { className?: string }) {
  return (
    <div
      className={`no-scrollbar mt-14 flex snap-x snap-mandatory scroll-pl-6 gap-5 overflow-x-auto px-6 pb-12 md:scroll-pl-12 md:px-12 ${className}`}
    >
      {tracks.map((t) => (
        <TrackCard key={t.id} track={t} queue={tracks} className="w-[76vw] max-w-[380px] snap-start" />
      ))}
    </div>
  );
}

/** Desktop: page scroll drives a pinned horizontal track. */
function PinnedTrack() {
  const outerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const distRef = useRef(0);
  const [dist, setDist] = useState(0);

  const { scrollYProgress } = useScroll({ target: outerRef, offset: ["start start", "end end"] });
  const x = useTransform(scrollYProgress, (p) => -p * distRef.current);

  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    const measure = () => {
      const d = Math.max(0, el.scrollWidth - window.innerWidth);
      distRef.current = d;
      setDist(d);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, []);

  return (
    <div
      ref={outerRef}
      className="relative hidden md:block"
      style={{ height: `calc(100vh + ${dist}px)` }}
    >
      <div className="sticky top-0 flex h-screen items-center overflow-hidden">
        <motion.div ref={trackRef} style={{ x }} className="flex w-max items-start gap-12 px-12 will-change-transform">
          {tracks.map((t, i) => (
            <TrackCard
              key={t.id}
              track={t}
              queue={tracks}
              className={`w-[30vw] min-w-[320px] max-w-[500px] ${i % 2 === 1 ? "mt-24" : ""}`}
            />
          ))}
        </motion.div>
        <div aria-hidden className="absolute inset-x-12 bottom-10 h-px bg-line">
          <motion.div className="h-full origin-left bg-bone/70" style={{ scaleX: scrollYProgress }} />
        </div>
      </div>
    </div>
  );
}

export default function MusicSection() {
  const reduce = useReducedMotion();
  const headRef = useRef<HTMLDivElement>(null);
  const headY = useParallax(headRef, ["10%", "-14%"]);

  return (
    <section id="music" className="relative pt-32 md:pt-48">
      <div ref={headRef} className="px-6 md:px-12">
        <motion.div style={{ y: headY }}>
          <MaskText
            as="h2"
            text="Music"
            className="font-display text-[30vw] leading-[0.85] tracking-[-0.04em] md:text-[20vw]"
          />
        </motion.div>
        <Reveal className="mt-8 max-w-[34ch] text-base text-mute md:ml-auto md:mt-[-3vw] md:max-w-[30ch]">
          Featured songs. Tap a cover to play; only one song plays at a time.
        </Reveal>
        <Reveal delay={0.1} className="mt-8 flex flex-wrap gap-x-8 gap-y-3 text-sm md:mt-6 md:justify-end">
          {[
            { href: "/songs", label: "All songs" },
            { href: "/artists", label: "Artists" },
            { href: "/albums", label: "Albums" },
          ].map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="underline decoration-bone/30 underline-offset-8 transition-colors hover:decoration-signal"
            >
              {l.label}
            </Link>
          ))}
        </Reveal>
      </div>

      {reduce ? <NativeRail /> : <NativeRail className="md:hidden" />}
      {!reduce && <PinnedTrack />}
    </section>
  );
}
