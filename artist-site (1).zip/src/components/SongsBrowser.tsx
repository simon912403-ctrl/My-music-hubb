"use client";

import { useMemo, useState } from "react";
import { searchCatalog, type Song } from "@/lib/catalog";
import { useLikes } from "./LikesProvider";
import PlayAllButton from "./PlayAllButton";
import SongList from "./SongList";

type Tab = "all" | "liked";

export default function SongsBrowser({ songs }: { songs: Song[] }) {
  const { likedIds } = useLikes();
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<Tab>("all");

  const visible = useMemo(() => {
    const base = query.trim() ? searchCatalog(query).songs : songs;
    return tab === "liked" ? base.filter((s) => likedIds.includes(s.id)) : base;
  }, [query, tab, songs, likedIds]);

  const tabClass = (t: Tab) =>
    `rounded-full border px-5 py-2.5 text-sm transition-colors duration-300 ${
      tab === t ? "border-bone bg-bone text-ink" : "border-bone/30 text-bone/80 hover:border-bone"
    }`;

  return (
    <section className="px-6 pb-24 pt-14 md:px-12 md:pt-20">
      <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
        <div className="w-full md:max-w-xl">
          <label htmlFor="songs-filter" className="text-sm text-mute">
            Search songs
          </label>
          <input
            id="songs-filter"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Title, artist or album"
            autoComplete="off"
            className="field [&::-webkit-search-cancel-button]:hidden"
          />
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button type="button" onClick={() => setTab("all")} className={tabClass("all")} aria-pressed={tab === "all"}>
            All songs
          </button>
          <button type="button" onClick={() => setTab("liked")} className={tabClass("liked")} aria-pressed={tab === "liked"}>
            Favourites ({likedIds.length})
          </button>
        </div>
      </div>

      <div className="mt-10 flex items-center justify-between gap-4">
        <p className="text-sm text-mute" aria-live="polite">
          {visible.length} {visible.length === 1 ? "song" : "songs"}
        </p>
        <PlayAllButton songs={visible} label="Play all" />
      </div>

      <div className="mt-6">
        {visible.length > 0 ? (
          <SongList songs={visible} />
        ) : (
          <p className="max-w-[46ch] border-t border-line pt-8 text-mute">
            {tab === "liked" && !query.trim()
              ? "No favourites yet. Tap the heart on any song to keep it here. Favourites are saved on this device."
              : `Nothing matches “${query.trim()}”. Try a song title, an artist or an album name.`}
          </p>
        )}
      </div>
    </section>
  );
}
