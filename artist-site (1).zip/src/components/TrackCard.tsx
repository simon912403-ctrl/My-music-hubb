"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import type { Track } from "@/data/content";
import { formatTime } from "@/lib/format";
import { usePlayer } from "./PlayerProvider";
import EqualizerBars from "./EqualizerBars";
import LikeButton from "./LikeButton";

export default function TrackCard({
  track,
  queue,
  className = "",
}: {
  track: Track;
  /** The list this card belongs to, so next/previous move through it */
  queue?: Track[];
  className?: string;
}) {
  const { current, playing, loading, error, currentTime, duration, progress, toggle, seek } = usePlayer();
  const active = current?.id === track.id;
  const isPlaying = active && playing;

  return (
    <article className={`group relative shrink-0 ${className}`}>
      <button
        type="button"
        onClick={() => toggle(track, queue)}
        aria-label={`${isPlaying ? "Pause" : "Play"} ${track.title}`}
        aria-pressed={isPlaying}
        className="relative block aspect-square w-full overflow-hidden bg-panel text-left"
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={track.cover}
          alt={`Cover artwork for ${track.title}`}
          width={800}
          height={800}
          loading="lazy"
          decoding="async"
          className={`h-full w-full object-cover transition-transform duration-[1400ms] ease-cine group-hover:scale-[1.06] ${
            isPlaying ? "scale-[1.04]" : ""
          }`}
        />
        <span
          aria-hidden
          className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent"
        />
        {active && <EqualizerBars playing={isPlaying} className="absolute bottom-4 left-4" />}

        <span
          aria-hidden
          className={`absolute bottom-4 right-4 grid h-14 w-14 place-items-center rounded-full border border-bone/40 backdrop-blur-sm transition-all duration-500 ease-cine group-hover:scale-110 group-hover:border-bone group-hover:bg-bone group-hover:text-ink ${
            isPlaying ? "bg-bone text-ink" : "bg-ink/30 text-bone"
          }`}
        >
          {isPlaying ? (
            <svg width="18" height="18" viewBox="0 0 18 18" fill="currentColor">
              <rect x="3" y="2" width="4" height="14" />
              <rect x="11" y="2" width="4" height="14" />
            </svg>
          ) : (
            <svg width="18" height="18" viewBox="0 0 18 18" fill="currentColor">
              <path d="M5 2.5v13L15.5 9z" />
            </svg>
          )}
        </span>
      </button>

      <div className="mt-5 flex items-baseline justify-between gap-4">
        <h3 className="font-display text-3xl leading-none tracking-tight md:text-4xl">{track.title}</h3>
        <LikeButton songId={track.id} title={track.title} className="-mr-3 -mt-2" />
      </div>
      <p className="mt-1 text-sm text-mute">
        <Link href={`/artists/${track.artistId}`} className="transition-colors hover:text-bone">
          {track.artist}
        </Link>
        <span className="tabular-nums"> · {track.year}</span>
      </p>

      <div className="relative mt-5 h-[2px] bg-line">
        {active && (
          <>
            <motion.div className="absolute inset-0 origin-left bg-signal" style={{ scaleX: progress }} />
            <input
              type="range"
              min={0}
              max={duration || 1}
              step={0.1}
              value={Math.min(currentTime, duration || 1)}
              onChange={(e) => seek(Number(e.target.value))}
              aria-label={`Seek ${track.title}`}
              className="absolute left-0 top-1/2 h-8 w-full -translate-y-1/2 cursor-pointer touch-none opacity-0"
            />
          </>
        )}
      </div>
      <p className="mt-3 h-4 text-xs tabular-nums text-mute" aria-live="polite">
        {active
          ? error
            ? error
            : loading && !isPlaying
              ? "Loading preview"
              : `${formatTime(currentTime)} / ${formatTime(duration)}`
          : "Tap the cover to play a preview"}
      </p>
    </article>
  );
}
