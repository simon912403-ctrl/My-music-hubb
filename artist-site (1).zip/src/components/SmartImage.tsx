"use client";

import { useEffect, useRef, useState } from "react";

type Props = {
  src: string;
  alt: string;
  className?: string;
  width?: number;
  height?: number;
  eager?: boolean;
  /** Text used for the fallback tile if the file is missing */
  fallbackLabel?: string;
};

/**
 * Lazy-loaded image with a graceful fallback tile, so a mistyped file name
 * shows a neutral placeholder instead of a broken-image icon.
 */
export default function SmartImage({ src, alt, className = "", width, height, eager, fallbackLabel }: Props) {
  const [failed, setFailed] = useState(false);
  const ref = useRef<HTMLImageElement>(null);

  useEffect(() => {
    setFailed(false);
    const img = ref.current;
    // The error can fire before React attaches listeners; check once after mount.
    if (img && img.complete && img.naturalWidth === 0 && src) setFailed(true);
  }, [src]);

  if (failed || !src) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`grid place-items-center bg-panel font-display text-4xl text-mute ${className}`}
      >
        {(fallbackLabel ?? alt).trim().charAt(0).toUpperCase()}
      </div>
    );
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      ref={ref}
      src={src}
      alt={alt}
      width={width}
      height={height}
      loading={eager ? "eager" : "lazy"}
      decoding="async"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
