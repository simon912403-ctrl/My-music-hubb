"use client";

import { AnimatePresence, motion } from "framer-motion";
import { site } from "@/lib/catalog";
import { EASE } from "@/lib/motion";
import MaskText from "./MaskText";

type Props = { entered: boolean; onEnter: () => void };

export default function IntroScreen({ entered, onEnter }: Props) {
  return (
    <AnimatePresence>
      {!entered && (
        <motion.div
          key="intro"
          className="fixed inset-0 z-[80] flex flex-col items-center justify-center overflow-hidden bg-ink px-6 text-center"
          initial={{ clipPath: "inset(0% 0% 0% 0%)" }}
          exit={{ clipPath: "inset(0% 0% 100% 0%)", transition: { duration: 1.2, ease: EASE } }}
          role="dialog"
          aria-label="Welcome"
        >
          {/* Slow drifting light. Radial gradients, not blur filters: cheap to composite. */}
          <div
            aria-hidden
            className="anim-drift-a pointer-events-none absolute -left-1/4 -top-1/4 h-[90vmax] w-[90vmax] will-change-transform"
            style={{ background: "radial-gradient(closest-side, rgba(157,184,255,0.22), transparent)" }}
          />
          <div
            aria-hidden
            className="anim-drift-b pointer-events-none absolute -bottom-1/3 -right-1/4 h-[80vmax] w-[80vmax] will-change-transform"
            style={{ background: "radial-gradient(closest-side, rgba(120,90,200,0.2), transparent)" }}
          />

          <MaskText
            as="h1"
            text={site.name}
            className="relative font-display text-[clamp(3.5rem,15vw,11rem)] leading-[0.9] tracking-[-0.03em]"
            delay={0.2}
          />

          <motion.p
            className="relative mt-6 max-w-[28ch] text-sm text-mute"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 1.2 }}
          >
            Best with sound on.
          </motion.p>

          <motion.button
            type="button"
            onClick={onEnter}
            autoFocus
            className="group relative mt-12 overflow-hidden rounded-full border border-bone/30 px-9 py-4 text-xs font-medium tracking-[0.28em] text-bone transition-colors duration-500 hover:border-bone hover:text-ink"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5, duration: 1, ease: EASE }}
          >
            <span
              aria-hidden
              className="absolute inset-0 origin-bottom scale-y-0 bg-bone transition-transform duration-500 ease-cine group-hover:scale-y-100"
            />
            <span className="relative">ENTER EXPERIENCE</span>
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
