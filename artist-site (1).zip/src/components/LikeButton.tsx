"use client";

import { motion } from "framer-motion";
import { useLikes } from "./LikesProvider";

export default function LikeButton({ songId, title, className = "" }: { songId: string; title: string; className?: string }) {
  const { isLiked, toggleLike } = useLikes();
  const liked = isLiked(songId);

  return (
    <motion.button
      type="button"
      onClick={() => toggleLike(songId)}
      whileTap={{ scale: 0.8 }}
      aria-pressed={liked}
      aria-label={liked ? `Remove ${title} from favourites` : `Add ${title} to favourites`}
      className={`grid h-11 w-11 shrink-0 place-items-center transition-colors duration-300 ${
        liked ? "text-signal" : "text-mute hover:text-bone"
      } ${className}`}
    >
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill={liked ? "currentColor" : "none"}
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
        aria-hidden
      >
        <path d="M12 20.5s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.6a4.3 4.3 0 0 1 7.5 2.7c0 5.6-7.5 10.2-7.5 10.2z" />
      </svg>
    </motion.button>
  );
}
