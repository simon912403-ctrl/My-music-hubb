"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { useReducedMotion } from "framer-motion";
import Lenis from "lenis";
import { scrollToId, setLenis } from "@/lib/scroll";

/**
 * - Smooth inertial scrolling on desktop (touch devices keep native momentum; off for reduced motion).
 * - Resets scroll to the top on page changes, or jumps to a #section when the link has one.
 */
export default function ScrollManager() {
  const pathname = usePathname();
  const reduce = useReducedMotion();

  useEffect(() => {
    if ("scrollRestoration" in history) history.scrollRestoration = "manual";
  }, []);

  useEffect(() => {
    if (reduce) return;
    const lenis = new Lenis({ lerp: 0.085, smoothWheel: true });
    setLenis(lenis);
    let raf = requestAnimationFrame(function loop(time) {
      lenis.raf(time);
      raf = requestAnimationFrame(loop);
    });
    return () => {
      cancelAnimationFrame(raf);
      lenis.destroy();
      setLenis(null);
    };
  }, [reduce]);

  useEffect(() => {
    const hash = window.location.hash.slice(1);
    if (hash) {
      const t = window.setTimeout(() => scrollToId(hash), 150);
      return () => window.clearTimeout(t);
    }
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}
