"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { EASE } from "@/lib/motion";
import { formatTime } from "@/lib/format";
import { usePlayer } from "./PlayerProvider";
import EqualizerBars from "./EqualizerBars";
import SmartImage from "./SmartImage";

const PlayIcon = () => (
  <svg width="16" height="16" viewBox="0 0 18 18" fill="currentColor" aria-hidden>
    <path d="M5 2.5v13L15.5 9z" />
  </svg>
);
const PauseIcon = () => (
  <svg width="16" height="16" viewBox="0 0 18 18" fill="currentColor" aria-hidden>
    <rect x="3" y="2" width="4" height="14" />
    <rect x="11" y="2" width="4" height="14" />
  </svg>
);
const SkipIcon = ({ flip }: { flip?: boolean }) => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="currentColor" aria-hidden style={flip ? { transform: "scaleX(-1)" } : undefined}>
    <path d="M3 3l9 6-9 6z" />
    <rect x="13" y="3" width="2" height="12" />
  </svg>
);
const VolumeIcon = ({ level }: { level: "off" | "low" | "high" }) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor" stroke="none" />
    {level === "off" ? (
      <path d="M16 9l5 6M21 9l-5 6" />
    ) : (
      <>
        <path d="M15.5 9.5a3.6 3.6 0 0 1 0 5" />
        {level === "high" && <path d="M18.3 7a7 7 0 0 1 0 10" />}
      </>
    )}
  </svg>
);

/** Persistent player: stays on screen across pages with play/pause, previous/next, seek and volume. */
export default function MusicPlayer() {
  const {
    current, playing, loading, error, currentTime, duration, volume, muted, hasNext, hasPrev, progress,
    pause, resume, next, prev, seek, setVolume, toggleMute, close,
  } = usePlayer();

  const shownVolume = muted ? 0 : volume;
  const level = shownVolume === 0 ? "off" : shownVolume < 0.5 ? "low" : "high";

  return (
    <AnimatePresence>
      {current && (
        <motion.div
          key="mini-player"
          role="region"
          aria-label="Audio player"
          className="fixed inset-x-3 z-[45] border border-line bg-ink/90 p-3 backdrop-blur-xl md:inset-x-auto md:right-6 md:w-[440px]"
          style={{ bottom: "calc(0.75rem + env(safe-area-inset-bottom))" }}
          initial={{ y: "140%", opacity: 0 }}
          animate={{ y: "0%", opacity: 1 }}
          exit={{ y: "140%", opacity: 0 }}
          transition={{ duration: 0.8, ease: EASE }}
        >
          <div className="flex items-center gap-3">
            <Link href={`/albums/${current.albumId}`} aria-label={`Open album ${current.album}`} className="shrink-0">
              <SmartImage
                src={current.cover}
                alt=""
                fallbackLabel={current.album}
                width={44}
                height={44}
                eager
                className="h-11 w-11 object-cover text-lg"
              />
            </Link>
            <div className="min-w-0 flex-1">
              <p className="truncate font-display text-xl leading-tight">{current.title}</p>
              <p className="truncate text-xs text-mute" aria-live="polite">
                {error ?? (
                  <Link href={`/artists/${current.artistId}`} className="hover:text-bone">
                    {current.artist}
                  </Link>
                )}
              </p>
            </div>
            <EqualizerBars playing={playing} className="hidden sm:flex" />
            <div className="flex items-center">
              <button
                type="button"
                onClick={prev}
                aria-label={hasPrev ? "Previous song" : "Restart song"}
                className="grid h-10 w-9 place-items-center text-bone/80 transition-colors hover:text-bone"
              >
                <SkipIcon flip />
              </button>
              <button
                type="button"
                onClick={() => (playing ? pause() : resume())}
                aria-label={playing ? "Pause" : "Play"}
                className="mx-1 grid h-11 w-11 place-items-center rounded-full bg-bone text-ink"
              >
                {playing ? <PauseIcon /> : <PlayIcon />}
              </button>
              <button
                type="button"
                onClick={next}
                disabled={!hasNext}
                aria-label="Next song"
                className="grid h-10 w-9 place-items-center text-bone/80 transition-colors hover:text-bone disabled:opacity-30 disabled:hover:text-bone/80"
              >
                <SkipIcon />
              </button>
              <button
                type="button"
                onClick={close}
                aria-label="Close player"
                className="ml-1 grid h-10 w-8 place-items-center text-mute transition-colors hover:text-bone"
              >
                <svg width="14" height="14" viewBox="0 0 14 14" stroke="currentColor" strokeWidth="1.5" aria-hidden>
                  <path d="M2 2l10 10M12 2L2 12" />
                </svg>
              </button>
            </div>
          </div>

          <div className="mt-2 flex items-center gap-3 text-xs tabular-nums text-mute">
            <span className="w-9 shrink-0">{loading && !playing ? "…" : formatTime(currentTime)}</span>
            <div className="relative h-[2px] flex-1 bg-line">
              <motion.div className="absolute inset-0 origin-left bg-signal" style={{ scaleX: progress }} />
              <input
                type="range"
                min={0}
                max={duration || 1}
                step={0.1}
                value={Math.min(currentTime, duration || 1)}
                onChange={(e) => seek(Number(e.target.value))}
                aria-label="Seek"
                className="absolute left-0 top-1/2 h-8 w-full -translate-y-1/2 cursor-pointer touch-none opacity-0"
              />
            </div>
            <span className="w-9 shrink-0 text-right">{formatTime(duration)}</span>
            <button
              type="button"
              onClick={toggleMute}
              aria-label={muted ? "Unmute" : "Mute"}
              className="grid h-8 w-7 shrink-0 place-items-center text-bone/80 transition-colors hover:text-bone"
            >
              <VolumeIcon level={level} />
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.02}
              value={shownVolume}
              onChange={(e) => setVolume(Number(e.target.value))}
              aria-label="Volume"
              className="h-8 w-16 shrink-0 cursor-pointer touch-none accent-signal sm:w-24"
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
