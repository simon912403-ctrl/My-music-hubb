"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { socials } from "@/data/content";
import { logo, site } from "@/lib/catalog";
import { scrollToId, scrollToTop } from "@/lib/scroll";
import SmartImage from "./SmartImage";

const pages = [
  { href: "/", label: "Home" },
  { href: "/songs", label: "Songs" },
  { href: "/artists", label: "Artists" },
  { href: "/albums", label: "Albums" },
];
const sections = [
  { id: "about", label: "About" },
  { id: "videos", label: "Videos" },
  { id: "tour", label: "Tour" },
  { id: "contact", label: "Contact" },
];

const linkClass =
  "text-bone/80 underline decoration-transparent underline-offset-4 transition-colors hover:text-bone hover:decoration-signal";

export default function Footer() {
  const pathname = usePathname();
  const onHome = pathname === "/";

  return (
    <footer className="relative border-t border-line px-6 pb-32 pt-20 md:px-12 md:pb-28 md:pt-28">
      <div className="flex items-end gap-4 md:gap-6">
        {logo && (
          <SmartImage
            src={logo}
            alt=""
            width={96}
            height={96}
            fallbackLabel={site.name}
            className="mb-2 h-[clamp(2.5rem,7vw,6rem)] w-[clamp(2.5rem,7vw,6rem)] shrink-0 object-contain"
          />
        )}
        <p className="font-display text-[clamp(3.75rem,15vw,15rem)] leading-[0.82] tracking-[-0.04em]">{site.name}</p>
      </div>

      <div className="mt-16 grid gap-10 text-sm sm:grid-cols-2 md:mt-24 lg:grid-cols-4">
        <ul className="space-y-3">
          {pages.map((p) => (
            <li key={p.href}>
              <Link
                href={p.href}
                onClick={(e) => {
                  if (p.href === "/" && onHome) {
                    e.preventDefault();
                    scrollToTop();
                  }
                }}
                className={linkClass}
              >
                {p.label}
              </Link>
            </li>
          ))}
        </ul>
        <ul className="space-y-3">
          {sections.map((s) => (
            <li key={s.id}>
              <Link
                href={`/#${s.id}`}
                onClick={(e) => {
                  if (onHome) {
                    e.preventDefault();
                    scrollToId(s.id);
                  }
                }}
                className={linkClass}
              >
                {s.label}
              </Link>
            </li>
          ))}
        </ul>
        <ul className="space-y-3">
          {socials.map((s) => (
            <li key={s.label}>
              <a href={s.href} target="_blank" rel="noopener noreferrer" className={linkClass}>
                {s.label}
              </a>
            </li>
          ))}
        </ul>
        <div className="flex items-end justify-between gap-6 sm:col-span-2 lg:col-span-1 lg:justify-end lg:gap-10">
          <p className="text-mute">
            © {new Date().getFullYear()} {site.name}. All rights reserved.
          </p>
          <button
            type="button"
            onClick={scrollToTop}
            aria-label="Back to top"
            className="group grid h-14 w-14 shrink-0 place-items-center rounded-full border border-bone/30 transition-colors duration-500 hover:border-bone hover:bg-bone hover:text-ink"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 18 18"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              className="transition-transform duration-500 ease-cine group-hover:-translate-y-0.5"
              aria-hidden
            >
              <path d="M9 15V3M3.5 8.5L9 3l5.5 5.5" />
            </svg>
          </button>
        </div>
      </div>
    </footer>
  );
}
