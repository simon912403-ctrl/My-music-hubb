"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

const KEY = "lowlight:liked-songs";

type LikesValue = {
  likedIds: string[];
  isLiked: (id: string) => boolean;
  toggleLike: (id: string) => void;
};

const LikesContext = createContext<LikesValue | null>(null);

export function useLikes() {
  const ctx = useContext(LikesContext);
  if (!ctx) throw new Error("useLikes must be used inside <LikesProvider>");
  return ctx;
}

function read(): string[] {
  try {
    const raw = window.localStorage.getItem(KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}

/** Favourites are stored in this browser (localStorage). No account or database needed. */
export function LikesProvider({ children }: { children: ReactNode }) {
  const [likedIds, setLikedIds] = useState<string[]>([]);
  const ref = useRef<string[]>([]);

  useEffect(() => {
    const initial = read();
    ref.current = initial;
    setLikedIds(initial);
    const onStorage = (e: StorageEvent) => {
      if (e.key !== KEY) return;
      const next = read();
      ref.current = next;
      setLikedIds(next);
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const toggleLike = useCallback((id: string) => {
    const cur = ref.current;
    const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
    ref.current = next;
    setLikedIds(next);
    try {
      window.localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      /* private mode / storage full: keep the in-memory state */
    }
  }, []);

  const value = useMemo<LikesValue>(
    () => ({ likedIds, isLiked: (id) => likedIds.includes(id), toggleLike }),
    [likedIds, toggleLike],
  );

  return <LikesContext.Provider value={value}>{children}</LikesContext.Provider>;
}
