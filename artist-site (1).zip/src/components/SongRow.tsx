"use client";

import Link from "next/link";
import type { Song } from "@/lib/catalog";
import { usePlayer } from "./PlayerProvider";
import EqualizerBars from "./EqualizerBars";
import LikeButton from "./LikeButton";
import SmartImage from "./SmartImage";

type Props = {
  song: Song;
  /** The list this row belongs to; next/previous move through it. */
  queue: Song[];
  showArtist?: boolean;
  showAlbum?: boolean;
};

export default function SongRow({ song, queue, showArtist = true, showAlbum = true }: Props) {
  const { current, playing, toggle } = usePlayer();
  const active = current?.id === song.id;
  const isPlaying = active && playing;
  const linkClass = "transition-colors hover:text-bone";

  return (
    <li className="group relative flex items-center gap-3 border-t border-line py-3 transition-colors duration-500 hover:bg-panel/70 md:gap-5 md:px-3">
      <button
        type="button"
        onClick={() => toggle(song, queue)}
        aria-label={`${isPlaying ? "Pause" : "Play"} ${song.title}`}
        aria-pressed={isPlaying}
        className="relative h-14 w-14 shrink-0 overflow-hidden bg-panel md:h-16 md:w-16"
      >
        <SmartImage
          src={song.cover}
          alt=""
          width={64}
          height={64}
          fallbackLabel={song.album}
          className="h-full w-full object-cover text-xl"
        />
        <span
          aria-hidden
          className={`absolute inset-0 grid place-items-center bg-ink/45 transition-opacity duration-300 md:group-hover:opacity-100 ${
            active ? "opacity-100" : "opacity-100 md:opacity-0"
          }`}
        >
          {isPlaying ? (
            <EqualizerBars playing />
          ) : (
            <svg width="16" height="16" viewBox="0 0 18 18" fill="currentColor">
              <path d="M5 2.5v13L15.5 9z" />
            </svg>
          )}
        </span>
      </button>

      <div className="min-w-0 flex-1">
        <p className={`truncate font-display text-2xl leading-tight md:text-3xl ${active ? "text-signal" : ""}`}>
          {song.title}
        </p>
        <p className="truncate text-sm text-mute">
          {showArtist && (
            <Link href={`/artists/${song.artistId}`} className={linkClass}>
              {song.artist}
            </Link>
          )}
          {showArtist && showAlbum && <span className="md:hidden"> · </span>}
          {showAlbum && (
            <Link href={`/albums/${song.albumId}`} className={`${linkClass} md:hidden`}>
              {song.album}
            </Link>
          )}
          {!showArtist && !showAlbum && <span className="tabular-nums">{song.year}</span>}
        </p>
      </div>

      {showAlbum && (
        <Link
          href={`/albums/${song.albumId}`}
          className={`${linkClass} hidden w-52 truncate text-sm text-mute md:block`}
        >
          {song.album}
        </Link>
      )}
      <span className="hidden w-12 text-sm tabular-nums text-mute md:block">{song.year}</span>
      <LikeButton songId={song.id} title={song.title} />
    </li>
  );
}
