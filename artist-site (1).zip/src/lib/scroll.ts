import type Lenis from "lenis";

let instance: Lenis | null = null;
let locked = false;

function applyLock() {
  if (typeof document === "undefined") return;
  document.documentElement.style.overflow = locked ? "hidden" : "";
  if (instance) {
    if (locked) instance.stop();
    else instance.start();
  }
}

export function setLenis(l: Lenis | null) {
  instance = l;
  applyLock();
}

/** Freeze / unfreeze page scrolling (intro screen, mobile menu, video modal). */
export function lockScroll(lock: boolean) {
  locked = lock;
  applyLock();
}

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  if (instance) instance.scrollTo(el, { duration: 1.6 });
  else el.scrollIntoView({ behavior: "auto", block: "start" });
}

export function scrollToTop() {
  if (instance) instance.scrollTo(0, { duration: 1.8 });
  else window.scrollTo({ top: 0, behavior: "auto" });
}
