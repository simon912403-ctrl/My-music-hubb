/** Shared easing: fast start, long soft landing. Feels cinematic without being slow. */
export const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];
