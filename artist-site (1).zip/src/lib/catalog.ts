/**
 * Turns the plain data in src/data/library.ts into ready-to-use objects
 * (full file paths, artist/album names attached) and provides lookups + search.
 * You should not need to edit this file.
 */
import {
  site,
  artists as rawArtists,
  albums as rawAlbums,
  songs as rawSongs,
} from "@/data/library";

export { site };

export type Artist = {
  id: string;
  name: string;
  image: string;
  bio: string;
  tagline?: string;
};

export type Album = {
  id: string;
  title: string;
  artistId: string;
  artist: string;
  year: number;
  cover: string;
  description?: string;
};

export type Song = {
  id: string;
  title: string;
  artistId: string;
  artist: string;
  albumId: string;
  album: string;
  year: number;
  cover: string;
  audio: string;
  featured: boolean;
};

/** "file.jpg" -> "/media/<folder>/file.jpg". Full paths and URLs are left alone. */
function media(folder: string, file: string): string {
  if (!file) return "";
  if (file.startsWith("/") || /^https?:\/\//.test(file)) return file;
  return `/media/${folder}/${file}`;
}

function fail(message: string): never {
  throw new Error(`[src/data/library.ts] ${message}`);
}

function assertUnique(kind: string, ids: string[]) {
  const seen = new Set<string>();
  for (const id of ids) {
    if (!id) fail(`A ${kind} is missing its "id".`);
    if (seen.has(id)) fail(`Two ${kind}s use the id "${id}". Every ${kind} id must be unique.`);
    seen.add(id);
  }
}

assertUnique("artist", rawArtists.map((a) => a.id));
assertUnique("album", rawAlbums.map((a) => a.id));
assertUnique("song", rawSongs.map((s) => s.id));

export const logo = media("branding", site.logo);

export const artists: Artist[] = rawArtists.map((a) => ({
  id: a.id,
  name: a.name,
  image: media("artists", a.image),
  bio: a.bio,
  tagline: a.tagline,
}));

const artistById = new Map(artists.map((a) => [a.id, a]));

export const albums: Album[] = rawAlbums.map((a) => {
  const artist = artistById.get(a.artistId);
  if (!artist) fail(`Album "${a.id}" uses artistId "${a.artistId}", but no artist has that id.`);
  return {
    id: a.id,
    title: a.title,
    artistId: a.artistId,
    artist: artist.name,
    year: a.year,
    cover: media("albums", a.cover),
    description: a.description,
  };
});

const albumById = new Map(albums.map((a) => [a.id, a]));

export const songs: Song[] = rawSongs.map((s) => {
  const album = albumById.get(s.albumId);
  if (!album) fail(`Song "${s.id}" uses albumId "${s.albumId}", but no album has that id.`);
  const artistId = s.artistId ?? album.artistId;
  const artist = artistById.get(artistId);
  if (!artist) fail(`Song "${s.id}" uses artistId "${artistId}", but no artist has that id.`);
  return {
    id: s.id,
    title: s.title,
    artistId,
    artist: artist.name,
    albumId: album.id,
    album: album.title,
    year: s.year ?? album.year,
    cover: album.cover,
    audio: media("songs", s.audio),
    featured: Boolean(s.featured),
  };
});

if (!artistById.has(site.mainArtistId)) {
  fail(`site.mainArtistId "${site.mainArtistId}" does not match any artist id.`);
}

export const featuredSongs: Song[] = songs.filter((s) => s.featured);

export const mainArtist: Artist = artistById.get(site.mainArtistId)!;

export const getArtist = (id: string) => artistById.get(id);
export const getAlbum = (id: string) => albumById.get(id);
export const songsByArtist = (artistId: string) => songs.filter((s) => s.artistId === artistId);
export const songsByAlbum = (albumId: string) => songs.filter((s) => s.albumId === albumId);
export const albumsByArtist = (artistId: string) => albums.filter((a) => a.artistId === artistId);

/* ---------------------------- search ---------------------------- */

function normalize(text: string) {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function matches(haystack: string, tokens: string[]) {
  const h = normalize(haystack);
  return tokens.every((t) => h.includes(t));
}

export type SearchResults = { songs: Song[]; artists: Artist[]; albums: Album[] };

export function searchCatalog(query: string): SearchResults {
  const tokens = normalize(query).split(" ").filter(Boolean);
  if (tokens.length === 0) return { songs: [], artists: [], albums: [] };
  return {
    songs: songs.filter((s) => matches(`${s.title} ${s.artist} ${s.album}`, tokens)),
    artists: artists.filter((a) => matches(a.name, tokens)),
    albums: albums.filter((a) => matches(`${a.title} ${a.artist}`, tokens)),
  };
}
