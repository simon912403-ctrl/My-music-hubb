/**
 * Homepage copy (hero, about, video, tour, social links).
 * Songs, artists, albums and branding live in src/data/library.ts.
 */
import { featuredSongs, mainArtist, type Song } from "@/lib/catalog";

/** Songs use the shared catalogue type (see src/data/library.ts). */
export type Track = Song;

export type TourDate = {
  id: string;
  /** ISO date, YYYY-MM-DD */
  date: string;
  city: string;
  venue: string;
  country: string;
  ticketUrl: string;
  soldOut?: boolean;
};

export type Social = { label: string; href: string };

const nameParts = mainArtist.name.split(" ");

/** Homepage hero artist. Name and tagline come from the artist chosen in library.ts (site.mainArtistId). */
export const artist = {
  name: mainArtist.name,
  first: nameParts[0],
  last: nameParts.slice(1).join(" "),
  tagline: mainArtist.tagline ?? "",
  email: "booking@maravoss.example",
  heroImage: "/media/hero.svg",
  portrait: "/media/portrait.svg",
};

export const nav = [
  { id: "music", label: "Music" },
  { id: "about", label: "About" },
  { id: "videos", label: "Videos" },
  { id: "tour", label: "Tour" },
  { id: "contact", label: "Contact" },
] as const;

/** Featured songs shown in the homepage music section. */
export const tracks: Track[] = featuredSongs;

export const about = {
  statement:
    "Mara Voss writes songs for the hour after the last train, when the city goes quiet and the room gets honest.",
  paragraphs: [
    "She started out producing demos on a secondhand laptop in a shared flat in Rotterdam, layering hushed vocals over analogue synth lines until the walls started to hum back. Those recordings became her debut EP, and a small club tour followed.",
    "Since then she has released two albums and a run of singles, built a live show around a wall of modular gear and a single spotlight, and played festival stages across Europe and North America.",
  ],
  stats: [
    { value: 9, suffix: "", decimals: 0, label: "Years active" },
    { value: 24, suffix: "", decimals: 0, label: "Releases" },
    { value: 312, suffix: "", decimals: 0, label: "Shows played" },
    { value: 48.2, suffix: "M", decimals: 1, label: "Streams" },
  ],
};

export const video = {
  title: "Glass Hours",
  subtitle: "Official video",
  poster: "/media/video-thumb.svg",
  src: "/media/video.mp4",
  info: [
    { label: "Directed by", value: "Ines Calder" },
    { label: "Released", value: "12 March 2026" },
    { label: "Runtime", value: "3:42" },
  ],
};

export const tour: TourDate[] = [
  { id: "t1", date: "2026-10-17", city: "Amsterdam", venue: "Paradiso", country: "Netherlands", ticketUrl: "#", soldOut: true },
  { id: "t2", date: "2026-10-19", city: "Berlin", venue: "Columbia Theater", country: "Germany", ticketUrl: "#" },
  { id: "t3", date: "2026-10-22", city: "Paris", venue: "La Cigale", country: "France", ticketUrl: "#" },
  { id: "t4", date: "2026-10-25", city: "London", venue: "Roundhouse", country: "United Kingdom", ticketUrl: "#" },
  { id: "t5", date: "2026-11-06", city: "New York", venue: "Webster Hall", country: "United States", ticketUrl: "#" },
  { id: "t6", date: "2026-11-09", city: "Toronto", venue: "Massey Hall", country: "Canada", ticketUrl: "#" },
  { id: "t7", date: "2026-11-14", city: "Los Angeles", venue: "The Wiltern", country: "United States", ticketUrl: "#" },
];

export const socials: Social[] = [
  { label: "Instagram", href: "https://instagram.com" },
  { label: "Spotify", href: "https://open.spotify.com" },
  { label: "YouTube", href: "https://youtube.com" },
  { label: "TikTok", href: "https://tiktok.com" },
];
