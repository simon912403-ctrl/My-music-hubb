/**
 * =====================================================================
 *  YOUR MUSIC LIBRARY  —  the one file you edit to change the catalogue
 * =====================================================================
 *
 * Put your files in these folders (all inside /public/media):
 *
 *   public/media/branding/   your logo            e.g. logo.svg or logo.png
 *   public/media/artists/    artist photos        e.g. mara-voss.jpg
 *   public/media/albums/     album cover images   e.g. glass-hours.jpg
 *   public/media/songs/      audio files          e.g. night-shift-radio.mp3
 *
 * Then write ONLY THE FILE NAME below (not the whole path).
 * File names are case-sensitive: "Cover.JPG" is not "cover.jpg".
 *
 * How the pieces connect:
 *   - every artist, album and song has a short unique `id` (lowercase, no spaces; use hyphens)
 *   - an album points to its artist with `artistId`
 *   - a song points to its album with `albumId` (its artist defaults to the album's artist)
 *
 * If an id is mistyped, the build stops with a message telling you which line to fix.
 */

export type ArtistEntry = {
  id: string;
  name: string;
  /** file in public/media/artists */
  image: string;
  bio: string;
  /** short one-liner shown on cards */
  tagline?: string;
};

export type AlbumEntry = {
  id: string;
  title: string;
  artistId: string;
  year: number;
  /** file in public/media/albums */
  cover: string;
  description?: string;
};

export type SongEntry = {
  id: string;
  title: string;
  albumId: string;
  /** only needed when the song's artist differs from the album's artist */
  artistId?: string;
  /** file in public/media/songs */
  audio: string;
  /** shows on the homepage "Featured" section */
  featured?: boolean;
  /** defaults to the album's year */
  year?: number;
};

/* ------------------------------------------------------------------ */
/*  1. Branding                                                        */
/* ------------------------------------------------------------------ */

export const site = {
  /** Shown in the menu, intro screen, footer and browser tab */
  name: "Low Light",
  tagline: "Independent music, made after midnight.",
  description:
    "Listen to songs, browse artists and albums, and save your favourites. Independent music from Low Light.",
  /** file in public/media/branding. Use "" to show the name as text only. */
  logo: "logo.svg",
  /** The artist featured in the homepage hero. Must match an artist id below. */
  mainArtistId: "mara-voss",
};

/* ------------------------------------------------------------------ */
/*  2. Artists                                                         */
/* ------------------------------------------------------------------ */

export const artists: ArtistEntry[] = [
  {
    id: "mara-voss",
    name: "Mara Voss",
    image: "mara-voss.svg",
    tagline: "Slow-burning electronic pop, recorded after midnight.",
    bio: "Mara Voss writes songs for the hour after the last train, when the city goes quiet and the room gets honest. She builds her records from hushed vocals and analogue synth lines, and plays them live with a wall of modular gear and a single spotlight.",
  },
  {
    id: "kesi-arden",
    name: "Kesi Arden",
    image: "kesi-arden.svg",
    tagline: "Warm bass, harbour-town nostalgia.",
    bio: "Kesi Arden is a producer and vocalist whose songs sit somewhere between soul and club music. Her debut album was written on ferries, in hotel rooms, and in the back of rented vans.",
  },
  {
    id: "ondine",
    name: "Ondine",
    image: "ondine.svg",
    tagline: "Ambient songs for low tide.",
    bio: "Ondine records patient, spacious music using field recordings from the coast. Her songs are built to be played quietly, late, and on repeat.",
  },
];

/* ------------------------------------------------------------------ */
/*  3. Albums (a single is just an album with one song)                */
/* ------------------------------------------------------------------ */

export const albums: AlbumEntry[] = [
  {
    id: "glass-hours",
    title: "Glass Hours",
    artistId: "mara-voss",
    year: 2026,
    cover: "glass-hours.svg",
    description: "Nine songs about the quiet part of the night. Recorded in one bedroom over one winter.",
  },
  {
    id: "salt-and-static",
    title: "Salt & Static",
    artistId: "mara-voss",
    year: 2025,
    cover: "salt-and-static.svg",
    description: "A single written on a coastal train, finished in a friend's kitchen.",
  },
  {
    id: "harbour-lights",
    title: "Harbour Lights",
    artistId: "kesi-arden",
    year: 2024,
    cover: "harbour-lights.svg",
    description: "Kesi Arden's debut: warm, low, and made to be played loud at night.",
  },
  {
    id: "low-tide",
    title: "Low Tide",
    artistId: "ondine",
    year: 2022,
    cover: "low-tide.svg",
    description: "Field recordings and slow synths, arranged for the hour the water pulls back.",
  },
];

/* ------------------------------------------------------------------ */
/*  4. Songs                                                           */
/* ------------------------------------------------------------------ */

export const songs: SongEntry[] = [
  { id: "night-shift-radio", title: "Night Shift Radio", albumId: "glass-hours", audio: "night-shift-radio.mp3", featured: true },
  { id: "glass-hours", title: "Glass Hours", albumId: "glass-hours", audio: "glass-hours.mp3", featured: true },
  { id: "salt-and-static", title: "Salt & Static", albumId: "salt-and-static", audio: "salt-and-static.mp3", featured: true },
  { id: "harbour-lights", title: "Harbour Lights", albumId: "harbour-lights", audio: "harbour-lights.mp3", featured: true },
  { id: "second-skin", title: "Second Skin", albumId: "harbour-lights", audio: "second-skin.mp3", year: 2023 },
  { id: "low-tide-hymn", title: "Low Tide Hymn", albumId: "low-tide", audio: "low-tide-hymn.mp3", featured: true },
];
