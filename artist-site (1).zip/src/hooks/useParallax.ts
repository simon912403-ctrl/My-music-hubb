"use client";

import type { RefObject } from "react";
import { useReducedMotion, useScroll, useTransform } from "framer-motion";

/**
 * Vertical parallax for an element while it crosses the viewport.
 * Returns a motion value ("-8%" -> "8%" etc). Flat when the user prefers reduced motion.
 */
export function useParallax(target: RefObject<HTMLElement | null>, range: [string, string]) {
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target, offset: ["start end", "end start"] });
  return useTransform(scrollYProgress, [0, 1], reduce ? ["0%", "0%"] : range);
}
