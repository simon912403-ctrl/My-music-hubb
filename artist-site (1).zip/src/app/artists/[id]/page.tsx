import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { albumsByArtist, artists, getArtist, songsByArtist } from "@/lib/catalog";
import AlbumCard from "@/components/AlbumCard";
import MaskText from "@/components/MaskText";
import PlayAllButton from "@/components/PlayAllButton";
import { ClipReveal, Reveal } from "@/components/Reveal";
import SmartImage from "@/components/SmartImage";
import SongList from "@/components/SongList";

export const dynamicParams = false;

export function generateStaticParams() {
  return artists.map((a) => ({ id: a.id }));
}

type Params = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { id } = await params;
  const artist = getArtist(id);
  if (!artist) return {};
  return { title: artist.name, description: artist.tagline ?? artist.bio.slice(0, 150) };
}

export default async function ArtistPage({ params }: Params) {
  const { id } = await params;
  const artist = getArtist(id);
  if (!artist) notFound();

  const albums = albumsByArtist(artist.id);
  const songs = songsByArtist(artist.id);

  return (
    <main>
      <section className="grid gap-10 px-6 pt-28 md:grid-cols-12 md:items-end md:gap-x-12 md:px-12 md:pt-40">
        <ClipReveal className="md:col-span-5">
          <div className="relative h-[58svh] overflow-hidden bg-panel md:aspect-[4/5] md:h-auto">
            <SmartImage
              src={artist.image}
              alt={`Photo of ${artist.name}`}
              width={800}
              height={1000}
              eager
              fallbackLabel={artist.name}
              className="h-full w-full object-cover"
            />
          </div>
        </ClipReveal>

        <div className="md:col-span-7">
          <MaskText
            as="h1"
            text={artist.name}
            className="font-display text-[clamp(3.75rem,13vw,10rem)] leading-[0.88] tracking-[-0.04em]"
          />
          {artist.tagline && <p className="mt-6 text-lg text-bone/80">{artist.tagline}</p>}
          <Reveal className="mt-6 max-w-[58ch] text-base leading-relaxed text-mute md:text-lg">
            <p>{artist.bio}</p>
          </Reveal>
          <Reveal className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-4" delay={0.1}>
            <PlayAllButton songs={songs} />
            <p className="text-sm text-mute">
              {albums.length} {albums.length === 1 ? "album" : "albums"} · {songs.length}{" "}
              {songs.length === 1 ? "song" : "songs"}
            </p>
          </Reveal>
        </div>
      </section>

      {albums.length > 0 && (
        <section className="px-6 pt-24 md:px-12 md:pt-36">
          <h2 className="font-display text-5xl tracking-tight md:text-7xl">Albums</h2>
          <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-14 md:grid-cols-3 md:gap-x-8 lg:grid-cols-4">
            {albums.map((a, i) => (
              <Reveal key={a.id} delay={(i % 4) * 0.08}>
                <AlbumCard album={a} showArtist={false} />
              </Reveal>
            ))}
          </div>
        </section>
      )}

      {songs.length > 0 && (
        <section className="px-6 pb-24 pt-24 md:px-12 md:pt-36">
          <h2 className="font-display text-5xl tracking-tight md:text-7xl">Songs</h2>
          <div className="mt-10">
            <SongList songs={songs} showArtist={false} />
          </div>
        </section>
      )}
    </main>
  );
}
