import type { Metadata } from "next";
import { artists } from "@/lib/catalog";
import PageHeader from "@/components/PageHeader";
import ArtistCard from "@/components/ArtistCard";
import { Reveal } from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Artists",
  description: "Browse every artist in the library.",
};

export default function ArtistsPage() {
  return (
    <main>
      <PageHeader title="Artists" description="Everyone who makes music here. Open an artist for their albums and songs." />
      <section className="grid grid-cols-2 gap-x-4 gap-y-14 px-6 pb-24 pt-14 md:grid-cols-3 md:gap-x-8 md:px-12 md:pt-20 lg:grid-cols-4">
        {artists.map((a, i) => (
          <Reveal key={a.id} delay={(i % 4) * 0.08}>
            <ArtistCard artist={a} />
          </Reveal>
        ))}
      </section>
    </main>
  );
}
