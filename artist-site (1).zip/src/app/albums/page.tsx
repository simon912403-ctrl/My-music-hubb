import type { Metadata } from "next";
import { albums } from "@/lib/catalog";
import PageHeader from "@/components/PageHeader";
import AlbumCard from "@/components/AlbumCard";
import { Reveal } from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Albums",
  description: "Browse every album and single in the library.",
};

export default function AlbumsPage() {
  return (
    <main>
      <PageHeader title="Albums" description="Albums and singles. Open one to see the full track list." />
      <section className="grid grid-cols-2 gap-x-4 gap-y-14 px-6 pb-24 pt-14 md:grid-cols-3 md:gap-x-8 md:px-12 md:pt-20 lg:grid-cols-4">
        {albums.map((a, i) => (
          <Reveal key={a.id} delay={(i % 4) * 0.08}>
            <AlbumCard album={a} />
          </Reveal>
        ))}
      </section>
    </main>
  );
}
