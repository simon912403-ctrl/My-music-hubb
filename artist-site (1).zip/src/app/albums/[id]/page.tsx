import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { albums, albumsByArtist, getAlbum, songsByAlbum } from "@/lib/catalog";
import AlbumCard from "@/components/AlbumCard";
import MaskText from "@/components/MaskText";
import PlayAllButton from "@/components/PlayAllButton";
import { ClipReveal, Reveal } from "@/components/Reveal";
import SmartImage from "@/components/SmartImage";
import SongList from "@/components/SongList";

export const dynamicParams = false;

export function generateStaticParams() {
  return albums.map((a) => ({ id: a.id }));
}

type Params = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { id } = await params;
  const album = getAlbum(id);
  if (!album) return {};
  return { title: `${album.title} — ${album.artist}`, description: album.description };
}

export default async function AlbumPage({ params }: Params) {
  const { id } = await params;
  const album = getAlbum(id);
  if (!album) notFound();

  const songs = songsByAlbum(album.id);
  const more = albumsByArtist(album.artistId).filter((a) => a.id !== album.id);

  return (
    <main>
      <section className="grid gap-10 px-6 pt-28 md:grid-cols-12 md:items-end md:gap-x-12 md:px-12 md:pt-40">
        <ClipReveal className="md:col-span-5">
          <div className="relative aspect-square w-full overflow-hidden bg-panel">
            <SmartImage
              src={album.cover}
              alt={`Cover of ${album.title}`}
              width={800}
              height={800}
              eager
              fallbackLabel={album.title}
              className="h-full w-full object-cover"
            />
          </div>
        </ClipReveal>

        <div className="md:col-span-7">
          <MaskText
            as="h1"
            text={album.title}
            className="font-display text-[clamp(3.5rem,12vw,9.5rem)] leading-[0.9] tracking-[-0.04em]"
          />
          <p className="mt-6 text-lg text-bone/80">
            <Link href={`/artists/${album.artistId}`} className="underline decoration-bone/30 underline-offset-8 transition-colors hover:decoration-signal">
              {album.artist}
            </Link>
            <span className="tabular-nums text-mute"> · {album.year}</span>
          </p>
          {album.description && (
            <Reveal className="mt-6 max-w-[54ch] text-base leading-relaxed text-mute md:text-lg">
              <p>{album.description}</p>
            </Reveal>
          )}
          <Reveal className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-4" delay={0.1}>
            <PlayAllButton songs={songs} label="Play album" />
            <p className="text-sm text-mute">
              {songs.length} {songs.length === 1 ? "song" : "songs"}
            </p>
          </Reveal>
        </div>
      </section>

      <section className="px-6 pt-20 md:px-12 md:pt-32">
        <SongList songs={songs} showAlbum={false} />
      </section>

      {more.length > 0 && (
        <section className="px-6 pb-24 pt-24 md:px-12 md:pt-36">
          <h2 className="font-display text-4xl tracking-tight md:text-6xl">More from {album.artist}</h2>
          <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-14 md:grid-cols-3 md:gap-x-8 lg:grid-cols-4">
            {more.map((a) => (
              <AlbumCard key={a.id} album={a} showArtist={false} />
            ))}
          </div>
        </section>
      )}
    </main>
  );
}
