import type { Metadata } from "next";
import { songs } from "@/lib/catalog";
import PageHeader from "@/components/PageHeader";
import SongsBrowser from "@/components/SongsBrowser";

export const metadata: Metadata = {
  title: "Songs",
  description: "Every song in the library. Search, play, and save favourites.",
};

export default function SongsPage() {
  return (
    <main>
      <PageHeader title="Songs" description="Every song in the library. Play one, or keep going through the list." />
      <SongsBrowser songs={songs} />
    </main>
  );
}
