import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-[80svh] flex-col items-start justify-center px-6 pt-32 md:px-12">
      <h1 className="font-display text-[clamp(4rem,16vw,12rem)] leading-[0.9] tracking-[-0.04em]">Not found</h1>
      <p className="mt-6 max-w-[40ch] text-mute">That page does not exist, or the song, artist or album was removed.</p>
      <Link
        href="/"
        className="mt-10 rounded-full border border-bone/40 px-8 py-4 text-sm transition-colors hover:bg-bone hover:text-ink"
      >
        Back to home
      </Link>
    </main>
  );
}
